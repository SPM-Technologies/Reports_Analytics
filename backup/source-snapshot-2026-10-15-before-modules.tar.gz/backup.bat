@echo off
rem Full backup (structure + all data) of the patientreg schema: backup\patientreg_full_YYYY-MM-DD.dump
rem The pg_trgm extension is included so the backup restores into an empty database.
call "%~dp0env.bat"
for /f %%d in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd"') do set "TODAY=%%d"
if not exist "%PROJECT_HOME%\backup" mkdir "%PROJECT_HOME%\backup"
set "FILE=%PROJECT_HOME%\backup\patientreg_full_%TODAY%.dump"
echo Backing up schema patientreg to %FILE% ...
docker exec %PG_CONTAINER% pg_dump -U postgres -d postgres -n patientreg --extension=pg_trgm -Fc -Z 6 > "%FILE%"
if errorlevel 1 (
    echo Backup FAILED.
    exit /b 1
)
echo Done.
echo To restore into an empty database (e.g. newdb):
echo   docker exec -i %PG_CONTAINER% pg_restore -U postgres -d newdb ^< "%FILE%"
