@echo off
rem Copies the WAR into Tomcat and starts Tomcat if it is not running. App URL: http://localhost:8080/patient-registration/
call "%~dp0env.bat"
if not exist "%PROJECT_HOME%\target\patient-registration.war" (
    echo WAR not found - run build.bat first.
    exit /b 1
)
copy /Y "%PROJECT_HOME%\target\patient-registration.war" "%CATALINA_HOME%\webapps\patient-registration.war"
if errorlevel 1 (
    echo Copy failed.
    exit /b 1
)
netstat -ano | findstr /R /C:":8080 .*LISTENING" >nul
if %errorlevel%==0 (
    echo Tomcat is already running - it will reload the application in a few seconds.
) else (
    echo Starting Tomcat...
    call "%CATALINA_HOME%\bin\startup.bat"
)
echo Open http://localhost:8080/patient-registration/
