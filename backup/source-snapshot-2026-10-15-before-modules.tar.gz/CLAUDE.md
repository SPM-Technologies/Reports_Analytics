# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

Spring MVC 6.2 (plain Java config, no Spring Boot, no ORM) + JSP patient registration app on Java 21 / Tomcat 11, PostgreSQL 18 in Docker. A 70-field registration form is stored across 6 tables plus a `department` master; two reports (patient register, department summary) render on screen and download as Excel (Apache POI) or PDF (OpenPDF). The DB holds ~1 lakh generated patients (Phase 2). Full human-facing documentation: `Docs/Patient-Registration-Project-Guide.html` — keep it in sync when behaviour, schema, config or counts change.

## Environment (local Windows machine)

- JDK: `D:\Pravin\jdk-21.0.12.1` (not on PATH; `JAVA_HOME` in the shell points elsewhere — always set it)
- Tomcat: `D:\Pravin\apache-tomcat-11.0.27` (port 8080, autoDeploy on; app at http://localhost:8080/patient-registration/)
- Maven 3.9.9 and its local repo are bundled in `tools\` (`tools\apache-maven-3.9.9`, `tools\m2repo`). Do not use `D:\Pravin\apache-maven-3.10.0`.
- PostgreSQL: Docker container `Postgres`, db `postgres`, schema `patientreg`, user/password in `src/main/resources/db.properties`.

## Commands

Scripts (`build.bat`, `deploy.bat`, `stop.bat`, `load-data.bat [rows]`, `backup.bat`) all source `env.bat`. From the Bash tool, the equivalents are:

```bash
# build (add -o for offline once plugins are cached; `clean` needs the clean plugin downloaded once)
cd /d/Pravin/patient-registration && JAVA_HOME="D:/Pravin/jdk-21.0.12.1" \
  ./tools/apache-maven-3.9.9/bin/mvn -q -B -Dmaven.repo.local="D:/Pravin/patient-registration/tools/m2repo" clean package

# deploy = copy the WAR; a running Tomcat hot-reloads it in ~10 s
cp target/patient-registration.war /d/Pravin/apache-tomcat-11.0.27/webapps/

# start Tomcat in the background if it is not running (logs go to stdout)
cd /d/Pravin/apache-tomcat-11.0.27 && JAVA_HOME="D:/Pravin/jdk-21.0.12.1" CATALINA_HOME="D:/Pravin/apache-tomcat-11.0.27" cmd //c "bin\\catalina.bat run"

# DB access
docker exec Postgres psql -U postgres -c "select count(*) from patientreg.patient"

# bulk data (adds rows; one transaction) and full backup
docker exec -i Postgres psql -U postgres -v ON_ERROR_STOP=1 -v rows=100000 < db/load-test-data.sql
docker exec Postgres pg_dump -U postgres -d postgres -n patientreg --extension=pg_trgm -Fc -Z 6 > backup/patientreg_full_YYYY-MM-DD.dump
```

There is no test suite and no linter. Verification has been done by building, redeploying, and exercising endpoints with `curl` (GET pages, POST `/patient/save` with form-encoded fields, GET `/reports/*/export?format=excel|pdf`) plus SQL checks.

## Architecture (big picture)

- **Two Spring contexts.** `WebAppInitializer` boots root `AppConfig` (DataSource/Hikari, `schema.sql` initializer, JDBC templates, tx manager; component-scans everything *except* `@Controller`/`@ControllerAdvice`) and servlet `WebConfig` (MVC, JSP resolver, `messageSource`; scans only controllers + `GlobalExceptionHandler`). A new controller-advice or controller must match these scan filters.
- **Schema is applied at every startup** by `DataSourceInitializer` running `src/main/resources/schema.sql`. It must stay idempotent (`IF NOT EXISTS`, `ADD COLUMN IF NOT EXISTS`, `ON CONFLICT DO NOTHING`). `ResourceDatabasePopulator` splits on `;`, so no `DO $$ … $$` blocks. This is the only migration mechanism.
- **One flat form bean, six tables.** `PatientForm` holds all fields; `PatientDao.insert` writes `patient` (generating `registration_no` = `REG` + year + 7-digit `reg_no_seq` inside the INSERT) then the five child tables in one `@Transactional` `PatientService.register`. `PatientDao.SELECT_FULL` reads it back with `BeanPropertyRowMapper`, relying on column aliases that match `PatientForm` property names.
- **Registration visit invariant.** `patient_visit.registration_visit = TRUE` marks the visit created at registration (partial unique index `ux_visit_registration`). All report SQL joins on this flag (`ReportDao.REGISTER_FROM`) instead of finding the first visit — new inserts must set it.
- **Reports.** `ReportDao` has one shared FROM + dynamically built WHERE (constant fragments, bound params) used by count, page (`LIMIT/OFFSET`, 50 rows, `registration_date DESC, patient_id DESC`), streaming export, and the department summary. Row arrays are positional: on-screen rows have `patient_id` at index 0, export rows do not; `ReportService` holds the header/width arrays that must match.
- **Exports stream.** `ReportService.export*` is `@Transactional(readOnly)` so PgJDBC uses a cursor (fetch size 2000); `ExcelExporter` uses SXSSF (200-row window) and `PdfExporter` flushes an incomplete `PdfPTable` every 500 rows, both fed by `ReportDefinition`'s row-consumer. `ReportController` runs exports through `ExportLimiter` (semaphore, `export.maxConcurrent`, 20 s wait → 503) and sets download headers *inside* the limiter so a "busy" reply is not saved as a file.
- **Errors.** `GlobalExceptionHandler` renders `error.jsp` for everything; only `ResponseStatusException` reasons are shown to users.

## Rules that span several files

- **Adding/changing a form field** touches: `schema.sql`, `PatientForm`, `PatientDao` (INSERT and `SELECT_FULL` alias), `PatientValidator` (`MAX_LENGTHS` must equal the column size; dropdowns go in `SELECT_FIELDS` + `model/Lookups`), `patient-form.jsp` (every field has a `<form:errors>`), `patient-view.jsp`, `db/load-test-data.sql` (it fills every column), and the HTML guide.
- **Server-side validation is authoritative**: dropdown values are whitelisted against `Lookups`, text lengths and numeric ranges are checked so nothing reaches the DB as a 500. `PatientController` disallows binding `patientId, registrationNo, status, bmi, deptName`.
- **JSP escaping**: user data must be output via `<c:out>` or Spring form tags; raw `${}` is only used for server-generated values. Every JSP starts with `<%@ include file="common/taglibs.jspf" %>` before using tags, then sets `pageTitle`/`activeNav` and includes `header.jspf`.
- Search uses `pg_trgm` GIN indexes (`first_name || ' ' || last_name`, `registration_no`, `mobile`); keep the WHERE expressions identical to the index expressions, and keep LIKE-wildcard escaping in `ReportDao`.

## Gotchas found in this environment

- Windows reports time zone `Asia/Calcutta`, which the Postgres container rejects at login; `AppConfig`'s static block switches the JVM default to `Asia/Kolkata`.
- `slf4j-api` and `log4j-api` are pinned in `pom.xml`; a transitive `slf4j-api` 1.7 silently turns all logging into a no-op.
- Running `.bat` files via the PowerShell tool has repeatedly failed to write files and the `.bat` files themselves disappeared afterwards (`deploy.bat`, `load-data.bat`, `backup.bat`). Prefer the Bash tool with direct commands; recreate scripts from the HTML guide if missing.
- `pg_dump -n patientreg` alone omits the `pg_trgm` extension and the dump will not restore; always add `--extension=pg_trgm`.
- Sequences are not rolled back: failed saves or aborted loads leave gaps in `reg_no_seq`/`patient_patient_id_seq`.
- Known open item: a non-numeric `/patient/{id}` returns 500 instead of 400.
- Deliberately out of scope (user decision): authentication/CSRF, and Unicode fonts for PDF (non-Latin text prints as `???`).
