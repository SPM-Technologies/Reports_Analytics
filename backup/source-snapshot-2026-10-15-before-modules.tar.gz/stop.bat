@echo off
call "%~dp0env.bat"
call "%CATALINA_HOME%\bin\shutdown.bat"
