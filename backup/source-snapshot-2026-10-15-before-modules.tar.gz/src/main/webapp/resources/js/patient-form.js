// Registration form helpers: age from DOB, BMI, show/hide insurance and permanent address.
(function () {
    function $(id) { return document.getElementById(id); }

    var dob = $('dob'), age = $('age');
    function calcAge() {
        if (!dob.value) { age.readOnly = false; return; }
        var b = new Date(dob.value), t = new Date();
        var a = t.getFullYear() - b.getFullYear();
        if (t.getMonth() < b.getMonth() || (t.getMonth() === b.getMonth() && t.getDate() < b.getDate())) a--;
        age.value = a < 0 ? '' : a;
        age.readOnly = true;
    }
    dob.addEventListener('change', calcAge);

    var h = $('height'), w = $('weight'), bmi = $('bmi');
    function calcBmi() {
        var hm = parseFloat(h.value) / 100, kg = parseFloat(w.value);
        bmi.value = hm > 0 && kg > 0 ? (kg / (hm * hm)).toFixed(1) : '';
    }
    h.addEventListener('input', calcBmi);
    w.addEventListener('input', calcBmi);

    function toggle(checkbox, box, showWhenChecked) {
        function apply() {
            var show = checkbox.checked === showWhenChecked;
            box.style.display = show ? '' : 'none';
        }
        checkbox.addEventListener('change', apply);
        apply();
    }
    toggle($('hasIns'), $('insBox'), true);
    toggle($('permSame'), $('permBox'), false);

    calcAge();
    calcBmi();
})();

// Prevent double registration from a double-click: disable the button once the form is submitted.
document.getElementById('regForm').addEventListener('submit', function () {
    var btn = this.querySelector('button[type=submit]');
    btn.disabled = true;
    btn.textContent = 'Saving...';
});
