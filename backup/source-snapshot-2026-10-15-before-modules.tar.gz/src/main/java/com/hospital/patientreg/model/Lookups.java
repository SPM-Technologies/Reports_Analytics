package com.hospital.patientreg.model;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Fixed dropdown values used by the registration form and report filters. */
public final class Lookups {

    public static final Map<String, List<String>> ALL = new LinkedHashMap<>();

    static {
        ALL.put("titles", List.of("Mr.", "Mrs.", "Ms.", "Master", "Baby", "Dr."));
        ALL.put("genders", List.of("Male", "Female", "Other"));
        ALL.put("bloodGroups", List.of("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"));
        ALL.put("maritalStatuses", List.of("Single", "Married", "Divorced", "Widowed"));
        ALL.put("religions", List.of("Hindu", "Muslim", "Christian", "Sikh", "Buddhist", "Jain", "Other"));
        ALL.put("languages", List.of("English", "Hindi", "Marathi", "Gujarati", "Tamil", "Telugu", "Kannada",
                "Malayalam", "Bengali", "Punjabi", "Other"));
        ALL.put("categories", List.of("GENERAL", "SENIOR_CITIZEN", "STAFF", "VIP", "BPL"));
        ALL.put("states", List.of("Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Delhi",
                "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand", "Karnataka",
                "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha",
                "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh",
                "Uttarakhand", "West Bengal"));
        ALL.put("relationships", List.of("Father", "Mother", "Spouse", "Son", "Daughter", "Brother", "Sister",
                "Guardian", "Friend", "Other"));
        ALL.put("holderRelationships", List.of("Self", "Spouse", "Parent", "Child", "Employer"));
        ALL.put("coverageTypes", List.of("Individual", "Family Floater", "Corporate", "Government Scheme"));
        ALL.put("smokingStatuses", List.of("Never", "Former", "Current"));
        ALL.put("alcoholUses", List.of("Never", "Occasional", "Regular"));
        ALL.put("vaccinationStatuses", List.of("Fully Vaccinated", "Partially Vaccinated", "Not Vaccinated",
                "Unknown"));
        ALL.put("visitTypes", List.of("NEW", "FOLLOW_UP", "EMERGENCY"));
        ALL.put("referralSources", List.of("Self", "Doctor", "Hospital", "Health Camp", "Online", "Other"));
        ALL.put("priorities", List.of("NORMAL", "URGENT", "CRITICAL"));
        ALL.put("paymentModes", List.of("CASH", "CARD", "UPI", "INSURANCE", "CREDIT"));
    }

    private Lookups() {
    }
}
