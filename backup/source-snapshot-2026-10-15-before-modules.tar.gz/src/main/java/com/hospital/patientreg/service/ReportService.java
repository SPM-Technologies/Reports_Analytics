package com.hospital.patientreg.service;

import com.hospital.patientreg.dao.PatientDao;
import com.hospital.patientreg.dao.ReportDao;
import com.hospital.patientreg.model.ReportFilter;
import com.hospital.patientreg.report.ExcelExporter;
import com.hospital.patientreg.report.PdfExporter;
import com.hospital.patientreg.report.ReportDefinition;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ReportService {

    public static final String[] REGISTER_HEADERS = {
            "Reg No", "Reg Date", "Patient Name", "Gender", "Age", "Mobile", "City", "State",
            "Department", "Doctor", "Visit Type", "Category", "Insured", "Fee (Rs)"};
    private static final float[] REGISTER_WIDTHS = {14, 10, 24, 7, 5, 11, 12, 13, 18, 18, 10, 10, 7, 9};

    public static final String[] SUMMARY_HEADERS = {
            "Department", "Total", "Male", "Female", "Other", "New", "Follow-up", "Emergency",
            "Insured", "Avg Age", "Total Fee (Rs)"};
    private static final float[] SUMMARY_WIDTHS = {24, 9, 9, 9, 9, 9, 10, 10, 9, 9, 14};

    private final ReportDao reportDao;
    private final PatientDao patientDao;
    private final ExcelExporter excel;
    private final PdfExporter pdf;

    public ReportService(ReportDao reportDao, PatientDao patientDao, ExcelExporter excel, PdfExporter pdf) {
        this.reportDao = reportDao;
        this.patientDao = patientDao;
        this.excel = excel;
        this.pdf = pdf;
    }

    // ---------------- screen data ----------------

    public long registerCount(ReportFilter f) {
        return reportDao.registerCount(f);
    }

    public List<Object[]> registerPage(ReportFilter f) {
        return reportDao.registerPage(f);
    }

    public List<Object[]> departmentSummary(ReportFilter f) {
        return reportDao.departmentSummary(f);
    }

    /** Grand total row for the summary: sums counts and fee, weighted average age. */
    public Object[] summaryTotals(List<Object[]> rows) {
        long[] sums = new long[8];
        BigDecimal ageWeighted = BigDecimal.ZERO;
        BigDecimal fee = BigDecimal.ZERO;
        for (Object[] r : rows) {
            for (int i = 0; i < 8; i++) sums[i] += (Long) r[i + 1];
            ageWeighted = ageWeighted.add(((BigDecimal) r[9]).multiply(BigDecimal.valueOf((Long) r[1])));
            fee = fee.add((BigDecimal) r[10]);
        }
        BigDecimal avgAge = sums[0] == 0 ? BigDecimal.ZERO
                : ageWeighted.divide(BigDecimal.valueOf(sums[0]), 1, RoundingMode.HALF_UP);
        return new Object[] {"GRAND TOTAL", sums[0], sums[1], sums[2], sums[3], sums[4], sums[5], sums[6],
                sums[7], avgAge, fee};
    }

    // ---------------- downloads ----------------

    /** Transactional so the PostgreSQL driver can use a cursor and stream rows. */
    @Transactional(readOnly = true)
    public void exportRegister(ReportFilter f, String format, OutputStream out) throws IOException {
        ReportDefinition def = new ReportDefinition(
                "Patient Registration Register",
                f.describe(patientDao.findDepartmentName(f.getDeptId())),
                REGISTER_HEADERS, REGISTER_WIDTHS,
                sink -> reportDao.registerStream(f, sink),
                null);
        write(def, format, out);
    }

    @Transactional(readOnly = true)
    public void exportSummary(ReportFilter f, String format, OutputStream out) throws IOException {
        List<Object[]> rows = reportDao.departmentSummary(f);
        ReportDefinition def = new ReportDefinition(
                "Department-wise Registration Summary",
                f.describe(null),
                SUMMARY_HEADERS, SUMMARY_WIDTHS,
                rows::forEach,
                summaryTotals(rows));
        write(def, format, out);
    }

    private void write(ReportDefinition def, String format, OutputStream out) throws IOException {
        if ("pdf".equals(format)) {
            pdf.export(def, out);
        } else {
            excel.export(def, out);
        }
    }
}
