# Patient Registration (Spring MVC + JSP + PostgreSQL)

Java 21 · Spring MVC 6.2 · Tomcat 11 · PostgreSQL · Apache POI (Excel) · OpenPDF (PDF). All libraries are open source.

## Run
| Step | Command |
|------|---------|
| Build WAR | `build.bat` |
| Deploy + start Tomcat | `deploy.bat` |
| Stop Tomcat | `stop.bat` |

App: http://localhost:8080/patient-registration/

Paths are set in `env.bat` (JDK and Tomcat from `D:\Pravin`, Maven + local repo in `tools\`).
DB settings: `src/main/resources/db.properties`. Tables are created automatically on startup (schema `patientreg`).

## Database (7 tables, 70 registration fields)
| Table | Contents |
|-------|----------|
| department | master list (10 departments seeded) |
| patient | demographics, reg no (`REG` + year + 7-digit sequence) |
| patient_contact | phone, email, address |
| patient_emergency_contact | emergency contact |
| patient_insurance | policy details |
| patient_medical_info | height, weight, BMI, history |
| patient_visit | department, doctor, complaint, fee |

## Screens
- **Dashboard** – counts
- **New Registration** – 6-section form with server-side validation
- **Report 1: Patient Register** – filters (date, department, gender, category, search), 50/page, Excel/PDF download
- **Report 2: Department Summary** – counts by gender / visit type / insurance, avg age, fee, grand total, Excel/PDF download

Exports stream rows from a DB cursor (Excel via SXSSF, PDF flushed in chunks), so they are ready for large data (Phase 2).

## Phase 2: bulk data (1 lakh patients)
| Step | Command |
|------|---------|
| Load test patients | `load-data.bat` (default 100000) or `load-data.bat 50000` |
| Full backup (schema + data) | `backup.bat` -> `backup/patientreg_full_YYYY-MM-DD.dump` |

- `db/load-test-data.sql` fills **every column of all six patient tables** with realistic, consistent data
  (age/title/marital status, city/state/pincode/language, department/doctor/complaint, insurance by category).
  It runs in one transaction (~16 s for 1 lakh); re-running adds more rows. Contact details are fictitious.
- Performance changes: `patient_visit.registration_visit` flag (plain join instead of per-row lookup),
  index matching the register sort order, `pg_trgm` indexes for search. Applied automatically on startup.
- Downloads: at most `export.maxConcurrent` (db.properties, default 3) run at once; extra requests wait up to
  20 s, then get a "server busy" page, so screens keep working during heavy exports.

Measured with 1 lakh patients: register page 1 ≈ 0.1 s, last page ≈ 0.4 s, search ≈ 0.2–0.3 s,
department summary ≈ 0.3 s, full Excel export ≈ 6 s (8 MB), full PDF export ≈ 11 s (4,167 pages, 20 MB).
