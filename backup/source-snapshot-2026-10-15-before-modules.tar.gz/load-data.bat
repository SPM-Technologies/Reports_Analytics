@echo off
rem Phase 2: loads bulk test patients (default 100000) into PostgreSQL. Usage: load-data.bat [rows]
call "%~dp0env.bat"
set "ROWS=%~1"
if "%ROWS%"=="" set "ROWS=100000"
echo Loading %ROWS% patients into container %PG_CONTAINER% ...
docker exec -i %PG_CONTAINER% psql -U postgres -d postgres -v ON_ERROR_STOP=1 -v rows=%ROWS% < "%PROJECT_HOME%\db\load-test-data.sql"
if errorlevel 1 (
    echo Load FAILED - nothing was inserted.
    exit /b 1
)
echo Done.
