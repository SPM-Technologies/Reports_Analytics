# Patient Registration (Spring MVC + JSP + PostgreSQL + ClickHouse reporting)

Java 21 · Spring MVC 6.2 · Tomcat 11 · PostgreSQL 18 · ClickHouse 25.3 · Kafka 3.9 + Debezium 3.0 (optional) ·
React 18 analytics UI · Apache POI (Excel) · OpenPDF (PDF). Everything is open source and runs in Docker.

## Run (only Docker Desktop is needed)
| Step | Command |
|------|---------|
| Start everything (first run builds the app image, ~3 min) | `start.bat` or `docker compose up -d --build` |
| Start with real-time reports (Kafka + Debezium) | `start.bat cdc` or `docker compose --profile cdc up -d --build` |
| Rebuild/redeploy the app after a code change | `deploy.bat` or `docker compose up -d --build app` |
| Stop (data is kept in Docker volumes) | `stop.bat` or `docker compose --profile cdc stop` |
| Load test patients (default 1 lakh) | `load-data.bat [rows]` or `docker compose --profile seed up seed seed-backfill` |
| Full backup | `backup.bat` -> `backup/patientreg_full_YYYY-MM-DD.dump` |

App: http://localhost:8080/patient-registration/ · Analytics UI: http://localhost:8080/patient-registration/app/

Passwords and the seed size are in `.env` (local POC values, plain text). Ports: 8080 app, 5432 PostgreSQL,
8123 ClickHouse HTTP, 8083 Debezium REST (cdc only).

### Containers (`docker-compose.yml`, project `patient-registration`)
| Service | What it does | Memory cap |
|---------|--------------|-----------|
| `postgres` (pr-postgres) | live database; `wal_level=logical`, 256 MB `/dev/shm` | 700 MB |
| `clickhouse` (pr-clickhouse) | analytics copy (`analytics`, test db `analytics_test`) | 1.2 GB |
| `app` (pr-app) | Tomcat 11 + the WAR, built from source by the `Dockerfile` | 900 MB |
| `pg-setup` | one-shot: test db `prtest`, accounts `reporting_ro`/`debezium`, publication | - |
| `analytics-setup` | one-shot: loads ClickHouse when empty, starts the one-minute sync | - |
| `kafka`, `debezium` (cdc) | real-time pipeline: outbox -> Kafka -> ClickHouse in ~2 s | 640 / 800 MB |
| `ch-cdc-setup`, `cdc-setup` (cdc) | one-shot: Kafka consumer tables in ClickHouse, Debezium connector | - |
| `seed`, `seed-backfill` (seed) | one-shot: bulk test data, then reload ClickHouse | - |

On first start of empty volumes the app creates its tables, `pg-setup` creates the accounts and ClickHouse is
filled automatically. Measured on this laptop with everything running: about 1.6 GB in total.

## Database (7 tables, 70 registration fields)
| Table | Contents |
|-------|----------|
| department | master list (10 departments seeded) |
| patient | demographics, reg no (`REG` + year + 7-digit sequence) |
| patient_contact | phone, email, address |
| patient_emergency_contact | emergency contact |
| patient_insurance | policy details |
| patient_medical_info | height, weight, BMI, history |
| patient_visit | department, doctor, complaint, fee |

Plus `report_outbox` (always empty; events go to the WAL for Debezium), `cdc_heartbeat`, view `v_patient_report`
(the published PatientSnapshot v1) and schema `reporting` (saved reports).

## Screens
- **Dashboard** – counts
- **New Registration** – 6-section form with server-side validation
- **Report 1: Patient Register** – filters (date, department, gender, category, search), 50/page, Excel/PDF download
- **Report 2: Department Summary** – counts by gender / visit type / insurance, avg age, fee, grand total, Excel/PDF download
- **Analytics** (`/app/`) – self-service report builder on ClickHouse: columns, measures, filters on any field,
  table/chart, saved reports and templates, Excel/PDF/CSV downloads. Never touches the live database.

## Bulk data (Phase 2)
- `db/load-test-data.sql` fills **every column of all six patient tables** with realistic, consistent data.
  It runs in one transaction (~16 s for 1 lakh); re-running adds more rows. Contact details are fictitious.
- Bulk SQL bypasses the outbox, so the seed profile reloads ClickHouse afterwards (`infra/clickhouse/pipeline/backfill.sql`).
- Downloads: at most `export.maxConcurrent` (default 3) run at once; extra requests wait up to 20 s, then get "server busy".

## Reporting data flow
1. Every registration writes a PatientSnapshot.v1 event into `report_outbox` in the same transaction.
2. Default mode: ClickHouse copies the last 15 minutes of `v_patient_report` every minute.
3. `cdc` profile: Debezium reads the outbox from the WAL -> Kafka topic `pr.patient.report` -> ClickHouse Kafka engine
   -> `analytics.patient_report` (about 2 s). Heartbeats every 10 s drive the "data as of" time. Malformed messages
   land in `analytics.pipeline_errors`. If Debezium, Kafka or ClickHouse is down, registration keeps working and
   the events arrive after it comes back (tested).

Reporting API (JSON): `GET /api/v1/datasets`, `POST /api/v1/query`, `POST /api/v1/query/export`,
`GET /api/v1/datasets/patients/fields/{field}/values?q=`, `GET /api/v1/freshness`, `/api/v1/reports` (saved reports).

## Development (on the host)
Maven multi-module build producing one WAR: `pr-shared`, `pr-registration`, `pr-reporting`, `pr-ui` (React), `pr-app`.
`build.bat` / `test.bat` use the JDK and Maven from `env.bat`; tests connect to the Docker databases on localhost.

| What | Command |
|------|---------|
| All automated tests (107: unit, API edge cases, outbox contract, architecture) | `test.bat` (containers running) |
| Browser end-to-end (12, Playwright in Edge; app container running) | `cd pr-ui` then `..\tools\node\npx playwright test` |
| Re-apply ClickHouse DDL | `bash infra/clickhouse-schema.sh` |
