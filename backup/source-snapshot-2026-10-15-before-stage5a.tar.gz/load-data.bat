@echo off
rem Loads bulk test patients (default 100000) into PostgreSQL, then reloads the analytics copy
rem (bulk SQL bypasses the outbox, so ClickHouse is refreshed by the backfill). Usage: load-data.bat [rows]
call "%~dp0env.bat"
cd /d "%PROJECT_HOME%"
set "ROWS=%~1"
if "%ROWS%"=="" set "ROWS=100000"
set "SEED_ROWS=%ROWS%"
echo Loading %ROWS% patients ...
docker compose --profile seed up seed seed-backfill
if errorlevel 1 (
    echo Load FAILED.
    exit /b 1
)
echo Done.
