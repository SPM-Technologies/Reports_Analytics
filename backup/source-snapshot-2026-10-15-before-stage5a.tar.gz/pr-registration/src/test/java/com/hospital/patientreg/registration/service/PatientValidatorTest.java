package com.hospital.patientreg.registration.service;

import static org.assertj.core.api.Assertions.assertThat;

import com.hospital.patientreg.registration.dao.PatientDao;
import com.hospital.patientreg.registration.model.Department;
import com.hospital.patientreg.registration.model.PatientForm;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

class PatientValidatorTest {

    /** Validator with a fixed department list instead of a database. */
    private final PatientValidator validator = new PatientValidator(new PatientDao(null) {
        @Override
        public List<Department> findActiveDepartments() {
            return List.of(new Department(1, "GEN", "General Medicine"), new Department(2, "CAR", "Cardiology"));
        }
    });

    static PatientForm validForm() {
        PatientForm f = new PatientForm();
        f.setRegistrationDate(LocalDate.now());
        f.setPatientCategory("GENERAL");
        f.setTitle("Mr.");
        f.setFirstName("Ravi");
        f.setLastName("Sharma");
        f.setGender("Male");
        f.setDateOfBirth(LocalDate.now().minusYears(40));
        f.setMobile("9876543210");
        f.setAddressLine1("12 MG Road");
        f.setCity("Pune");
        f.setState("Maharashtra");
        f.setPincode("411001");
        f.setCountry("India");
        f.setEmergencyName("Sita Sharma");
        f.setEmergencyRelationship("Spouse");
        f.setEmergencyPhone("9876500000");
        f.setDeptId(2);
        f.setConsultingDoctor("Dr. Mehta");
        f.setVisitType("NEW");
        f.setPriority("NORMAL");
        f.setChiefComplaint("Chest pain");
        f.setPaymentMode("UPI");
        f.setRegistrationFee(new BigDecimal("300"));
        return f;
    }

    private Errors validate(PatientForm f) {
        Errors errors = new BeanPropertyBindingResult(f, "patient");
        validator.validate(f, errors);
        return errors;
    }

    @Test
    void validFormHasNoErrors() {
        assertThat(validate(validForm()).getAllErrors()).isEmpty();
    }

    @Test
    void requiredFieldsAreReported() {
        PatientForm f = new PatientForm();
        Errors e = validate(f);
        assertThat(e.getFieldErrors()).extracting("field")
                .contains("firstName", "lastName", "gender", "ageYears", "mobile", "addressLine1", "city", "state",
                        "pincode", "emergencyName", "emergencyRelationship", "emergencyPhone", "deptId",
                        "consultingDoctor", "chiefComplaint", "paymentMode");
    }

    @Test
    void dropdownValuesMustComeFromLookups() {
        PatientForm f = validForm();
        f.setGender("<svg/x='");
        f.setVisitType("WALKIN");
        Errors e = validate(f);
        assertThat(e.getFieldError("gender")).isNotNull();
        assertThat(e.getFieldError("visitType")).isNotNull();
    }

    @Test
    void textLongerThanColumnIsRejected() {
        PatientForm f = validForm();
        f.setOccupation("a".repeat(61));
        assertThat(validate(f).getFieldError("occupation").getDefaultMessage()).isEqualTo("Maximum 60 characters");
    }

    @Test
    void formatsAndRangesAreChecked() {
        PatientForm f = validForm();
        f.setMobile("12345");
        f.setPincode("ABC");
        f.setRegistrationFee(new BigDecimal("99999999"));
        f.setDeptId(999);
        Errors e = validate(f);
        assertThat(e.getFieldErrors()).extracting("field").contains("mobile", "pincode", "registrationFee", "deptId");
    }

    @Test
    void datesAreChecked() {
        PatientForm f = validForm();
        f.setRegistrationDate(LocalDate.now().plusDays(1));
        f.setDateOfBirth(LocalDate.now().minusYears(200));
        Errors e = validate(f);
        assertThat(e.getFieldError("registrationDate")).isNotNull();
        assertThat(e.getFieldError("dateOfBirth")).isNotNull();
    }

    @Test
    void insuranceFieldsRequiredOnlyWhenInsured() {
        PatientForm f = validForm();
        f.setHasInsurance(true);
        Errors e = validate(f);
        assertThat(e.getFieldErrors()).extracting("field").contains("insuranceProvider", "policyNumber", "policyValidTo");
        f.setHasInsurance(false);
        assertThat(validate(f).getAllErrors()).isEmpty();
    }
}
