package com.hospital.patientreg.registration.web;

import com.hospital.patientreg.registration.model.Lookups;
import com.hospital.patientreg.registration.model.PatientForm;
import com.hospital.patientreg.registration.service.PatientService;
import com.hospital.patientreg.registration.service.PatientValidator;
import java.time.LocalDate;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

@Controller
@RequestMapping("/patient")
public class PatientController {

    private final PatientService patientService;
    private final PatientValidator validator;

    public PatientController(PatientService patientService, PatientValidator validator) {
        this.patientService = patientService;
        this.validator = validator;
    }

    @InitBinder("patient")
    public void initBinder(WebDataBinder binder) {
        binder.registerCustomEditor(String.class, new StringTrimmerEditor(true)); // blank -> null
        // generated or derived values must never come from the request
        binder.setDisallowedFields("patientId", "registrationNo", "status", "bmi", "deptName");
    }

    @GetMapping("/new")
    public String newForm(Model model) {
        PatientForm form = new PatientForm();
        form.setRegistrationDate(LocalDate.now());
        form.setVisitDate(LocalDate.now());
        model.addAttribute("patient", form);
        return formView(model);
    }

    @PostMapping("/save")
    public String save(@ModelAttribute("patient") PatientForm form, BindingResult result,
                       Model model, RedirectAttributes redirect) {
        validator.validate(form, result);
        if (result.hasErrors()) {
            model.addAttribute("errorCount", result.getErrorCount());
            return formView(model);
        }
        long id = patientService.register(form);
        redirect.addFlashAttribute("message",
                "Patient registered successfully. Registration No: " + form.getRegistrationNo());
        return "redirect:/patient/" + id;
    }

    @GetMapping("/{id}")
    public String view(@PathVariable long id, Model model) {
        PatientForm patient = patientService.find(id);
        if (patient == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Patient not found");
        }
        model.addAttribute("p", patient);
        return "patient-view";
    }

    private String formView(Model model) {
        model.addAttribute("lk", Lookups.ALL);
        model.addAttribute("departments", patientService.departments());
        return "patient-form";
    }
}
