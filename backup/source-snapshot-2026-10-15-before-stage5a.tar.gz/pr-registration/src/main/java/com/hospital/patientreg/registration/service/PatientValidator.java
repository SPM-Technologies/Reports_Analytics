package com.hospital.patientreg.registration.service;

import com.hospital.patientreg.registration.dao.PatientDao;
import com.hospital.patientreg.registration.model.Department;
import com.hospital.patientreg.registration.model.Lookups;
import com.hospital.patientreg.registration.model.PatientForm;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

/**
 * Server-side validation for the registration form. The browser checks are only a convenience:
 * everything that reaches the database (allowed values, lengths, numeric ranges) is checked here.
 */
@Component
public class PatientValidator implements Validator {

    private static final Pattern PHONE = Pattern.compile("\\d{10}");
    private static final Pattern PINCODE = Pattern.compile("\\d{6}");
    private static final Pattern AADHAAR = Pattern.compile("\\d{12}");
    private static final Pattern EMAIL = Pattern.compile("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$");

    private static final BigDecimal MAX_FEE = new BigDecimal("100000");
    private static final BigDecimal MAX_SUM_INSURED = new BigDecimal("100000000");
    private static final int MAX_AGE = 130;

    /** Dropdown-backed fields and the only values they may hold. */
    private static final Map<String, String> SELECT_FIELDS = new LinkedHashMap<>();
    /** Free-text fields and their column sizes in schema.sql. */
    private static final Map<String, Integer> MAX_LENGTHS = new LinkedHashMap<>();

    static {
        SELECT_FIELDS.put("title", "titles");
        SELECT_FIELDS.put("gender", "genders");
        SELECT_FIELDS.put("bloodGroup", "bloodGroups");
        SELECT_FIELDS.put("maritalStatus", "maritalStatuses");
        SELECT_FIELDS.put("religion", "religions");
        SELECT_FIELDS.put("preferredLanguage", "languages");
        SELECT_FIELDS.put("patientCategory", "categories");
        SELECT_FIELDS.put("state", "states");
        SELECT_FIELDS.put("emergencyRelationship", "relationships");
        SELECT_FIELDS.put("holderRelationship", "holderRelationships");
        SELECT_FIELDS.put("coverageType", "coverageTypes");
        SELECT_FIELDS.put("smokingStatus", "smokingStatuses");
        SELECT_FIELDS.put("alcoholUse", "alcoholUses");
        SELECT_FIELDS.put("vaccinationStatus", "vaccinationStatuses");
        SELECT_FIELDS.put("visitType", "visitTypes");
        SELECT_FIELDS.put("referralSource", "referralSources");
        SELECT_FIELDS.put("priority", "priorities");
        SELECT_FIELDS.put("paymentMode", "paymentModes");

        MAX_LENGTHS.put("firstName", 60);
        MAX_LENGTHS.put("middleName", 60);
        MAX_LENGTHS.put("lastName", 60);
        MAX_LENGTHS.put("nationality", 40);
        MAX_LENGTHS.put("occupation", 60);
        MAX_LENGTHS.put("email", 100);
        MAX_LENGTHS.put("addressLine1", 150);
        MAX_LENGTHS.put("addressLine2", 150);
        MAX_LENGTHS.put("city", 60);
        MAX_LENGTHS.put("district", 60);
        MAX_LENGTHS.put("country", 60);
        MAX_LENGTHS.put("permanentAddress", 300);
        MAX_LENGTHS.put("emergencyName", 100);
        MAX_LENGTHS.put("emergencyAddress", 300);
        MAX_LENGTHS.put("insuranceProvider", 100);
        MAX_LENGTHS.put("policyNumber", 40);
        MAX_LENGTHS.put("groupNumber", 40);
        MAX_LENGTHS.put("policyHolderName", 100);
        MAX_LENGTHS.put("knownAllergies", 300);
        MAX_LENGTHS.put("chronicConditions", 300);
        MAX_LENGTHS.put("currentMedications", 300);
        MAX_LENGTHS.put("pastSurgeries", 300);
        MAX_LENGTHS.put("familyHistory", 300);
        MAX_LENGTHS.put("disability", 100);
        MAX_LENGTHS.put("consultingDoctor", 100);
        MAX_LENGTHS.put("referredBy", 100);
        MAX_LENGTHS.put("chiefComplaint", 300);
        MAX_LENGTHS.put("symptomDuration", 30);
        MAX_LENGTHS.put("remarks", 300);
    }

    private final PatientDao patientDao;

    public PatientValidator(PatientDao patientDao) {
        this.patientDao = patientDao;
    }

    @Override
    public boolean supports(Class<?> clazz) {
        return PatientForm.class.equals(clazz);
    }

    @Override
    public void validate(Object target, Errors e) {
        PatientForm f = (PatientForm) target;
        LocalDate today = LocalDate.now();
        LocalDate regDate = f.getRegistrationDate() != null ? f.getRegistrationDate() : today;

        // personal
        required(e, "firstName", "First name");
        required(e, "lastName", "Last name");
        required(e, "gender", "Gender");
        if (f.getRegistrationDate() != null && f.getRegistrationDate().isAfter(today)) {
            e.rejectValue("registrationDate", "future", "Registration date cannot be in the future");
        }
        if (f.getDateOfBirth() != null) {
            if (f.getDateOfBirth().isAfter(regDate)) {
                e.rejectValue("dateOfBirth", "future", "Date of birth cannot be after the registration date");
            } else if (f.getDateOfBirth().isBefore(regDate.minusYears(MAX_AGE))) {
                e.rejectValue("dateOfBirth", "range", "Date of birth is more than " + MAX_AGE + " years ago");
            }
        } else if (f.getAgeYears() == null) {
            e.rejectValue("ageYears", "required", "Enter date of birth or age");
        }
        if (f.getAgeYears() != null && (f.getAgeYears() < 0 || f.getAgeYears() > MAX_AGE)) {
            e.rejectValue("ageYears", "range", "Age must be between 0 and " + MAX_AGE);
        }
        pattern(e, "nationalId", f.getNationalId(), AADHAAR, "Aadhaar number must be 12 digits");
        required(e, "patientCategory", "Patient category");

        // contact
        required(e, "mobile", "Mobile");
        pattern(e, "mobile", f.getMobile(), PHONE, "Mobile must be 10 digits");
        pattern(e, "alternatePhone", f.getAlternatePhone(), PHONE, "Phone must be 10 digits");
        pattern(e, "email", f.getEmail(), EMAIL, "Invalid email address");
        required(e, "addressLine1", "Address");
        required(e, "city", "City");
        required(e, "state", "State");
        required(e, "pincode", "Pincode");
        pattern(e, "pincode", f.getPincode(), PINCODE, "Pincode must be 6 digits");
        required(e, "country", "Country");
        if (!f.isPermSameAsCurrent()) {
            required(e, "permanentAddress", "Permanent address");
        }

        // emergency
        required(e, "emergencyName", "Emergency contact name");
        required(e, "emergencyRelationship", "Relationship");
        required(e, "emergencyPhone", "Emergency phone");
        pattern(e, "emergencyPhone", f.getEmergencyPhone(), PHONE, "Phone must be 10 digits");
        pattern(e, "emergencyAltPhone", f.getEmergencyAltPhone(), PHONE, "Phone must be 10 digits");

        // insurance
        if (f.isHasInsurance()) {
            required(e, "insuranceProvider", "Insurance provider");
            required(e, "policyNumber", "Policy number");
            required(e, "policyValidTo", "Valid to");
            if (f.getPolicyValidFrom() != null && f.getPolicyValidTo() != null
                    && f.getPolicyValidTo().isBefore(f.getPolicyValidFrom())) {
                e.rejectValue("policyValidTo", "range", "Valid-to date must be after valid-from date");
            }
            range(e, "sumInsured", f.getSumInsured(), MAX_SUM_INSURED);
        }

        // medical
        if (f.getHeightCm() != null && (f.getHeightCm().doubleValue() < 30 || f.getHeightCm().doubleValue() > 250)) {
            e.rejectValue("heightCm", "range", "Height must be 30-250 cm");
        }
        if (f.getWeightKg() != null && (f.getWeightKg().doubleValue() < 1 || f.getWeightKg().doubleValue() > 400)) {
            e.rejectValue("weightKg", "range", "Weight must be 1-400 kg");
        }

        // visit
        if (f.getDeptId() == null) {
            e.rejectValue("deptId", "required", "Department is required");
        } else if (patientDao.findActiveDepartments().stream().map(Department::deptId)
                .noneMatch(id -> id == f.getDeptId())) {
            e.rejectValue("deptId", "invalid", "Select a valid department");
        }
        required(e, "consultingDoctor", "Consulting doctor");
        required(e, "visitType", "Visit type");
        required(e, "chiefComplaint", "Chief complaint");
        required(e, "priority", "Priority");
        required(e, "paymentMode", "Payment mode");
        if (f.getVisitDate() != null) {
            if (f.getVisitDate().isAfter(today)) {
                e.rejectValue("visitDate", "future", "Visit date cannot be in the future");
            } else if (f.getVisitDate().isBefore(regDate)) {
                e.rejectValue("visitDate", "range", "Visit date cannot be before the registration date");
            }
        }
        range(e, "registrationFee", f.getRegistrationFee(), MAX_FEE);

        // dropdown values must come from the fixed lists; text must fit its column
        SELECT_FIELDS.forEach((field, list) -> {
            Object value = e.getFieldValue(field);
            if (value instanceof String s && !s.isEmpty() && !e.hasFieldErrors(field)
                    && !Lookups.ALL.get(list).contains(s)) {
                e.rejectValue(field, "invalid", "Select a valid value");
            }
        });
        MAX_LENGTHS.forEach((field, max) -> {
            Object value = e.getFieldValue(field);
            if (value instanceof String s && s.length() > max && !e.hasFieldErrors(field)) {
                e.rejectValue(field, "length", "Maximum " + max + " characters");
            }
        });
    }

    private static void required(Errors e, String field, String label) {
        if (!e.hasFieldErrors(field)) {
            ValidationUtils.rejectIfEmptyOrWhitespace(e, field, "required", label + " is required");
        }
    }

    private static void pattern(Errors e, String field, String value, Pattern p, String msg) {
        if (value != null && !value.isBlank() && !p.matcher(value.trim()).matches() && !e.hasFieldErrors(field)) {
            e.rejectValue(field, "format", msg);
        }
    }

    private static void range(Errors e, String field, BigDecimal value, BigDecimal max) {
        if (value == null || e.hasFieldErrors(field)) return;
        if (value.signum() < 0) {
            e.rejectValue(field, "range", "Cannot be negative");
        } else if (value.compareTo(max) > 0) {
            e.rejectValue(field, "range", "Cannot exceed " + max.toPlainString());
        } else if (value.scale() > 2) {
            e.rejectValue(field, "range", "At most 2 decimal places");
        }
    }
}
