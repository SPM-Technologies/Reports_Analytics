package com.hospital.patientreg.registration.service;

import com.hospital.patientreg.registration.dao.PatientDao;
import com.hospital.patientreg.registration.model.Department;
import com.hospital.patientreg.registration.model.PatientForm;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PatientService {

    private final PatientDao patientDao;

    public PatientService(PatientDao patientDao) {
        this.patientDao = patientDao;
    }

    /** Saves the registration into all tables in one transaction and returns the new patient id. */
    @Transactional
    public long register(PatientForm form) {
        prepare(form);
        patientDao.insert(form);
        return form.getPatientId();
    }

    @Transactional(readOnly = true)
    public PatientForm find(long patientId) {
        return patientDao.findById(patientId);
    }

    public List<Department> departments() {
        return patientDao.findActiveDepartments();
    }

    public Map<String, Object> dashboardCounts() {
        return patientDao.dashboardCounts();
    }

    /** Fills derived values: dates, age from DOB, BMI, cleared insurance/permanent-address fields. */
    static void prepare(PatientForm f) {
        LocalDate today = LocalDate.now();
        if (f.getRegistrationDate() == null) f.setRegistrationDate(today);
        if (f.getVisitDate() == null) f.setVisitDate(f.getRegistrationDate());
        if (f.getDateOfBirth() != null) {
            f.setAgeYears(Period.between(f.getDateOfBirth(), f.getRegistrationDate()).getYears());
        }
        if (f.getHeightCm() != null && f.getWeightKg() != null && f.getHeightCm().signum() > 0) {
            BigDecimal meters = f.getHeightCm().divide(BigDecimal.valueOf(100));
            f.setBmi(f.getWeightKg().divide(meters.multiply(meters), 1, RoundingMode.HALF_UP));
        } else {
            f.setBmi(null);
        }
        if (f.isPermSameAsCurrent()) {
            f.setPermanentAddress(null);
        }
        if (!f.isHasInsurance()) {
            f.setInsuranceProvider(null);
            f.setPolicyNumber(null);
            f.setGroupNumber(null);
            f.setPolicyHolderName(null);
            f.setHolderRelationship(null);
            f.setPolicyValidFrom(null);
            f.setPolicyValidTo(null);
            f.setCoverageType(null);
            f.setSumInsured(null);
        }
        if (f.getRegistrationFee() == null) f.setRegistrationFee(BigDecimal.ZERO);
    }
}
