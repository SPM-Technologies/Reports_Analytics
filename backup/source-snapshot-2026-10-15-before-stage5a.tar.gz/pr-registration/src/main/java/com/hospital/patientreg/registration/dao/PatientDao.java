package com.hospital.patientreg.registration.dao;

import com.hospital.patientreg.registration.model.Department;
import com.hospital.patientreg.registration.model.PatientForm;
import java.util.List;
import java.util.Map;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

@Repository
public class PatientDao {

    private static final String INSERT_PATIENT = """
            INSERT INTO patient (registration_no, registration_date, title, first_name, middle_name, last_name,
                gender, date_of_birth, age_years, blood_group, marital_status, nationality, religion, occupation,
                national_id, preferred_language, patient_category, status)
            VALUES ('REG' || to_char(:registrationDate, 'YYYY') || lpad(nextval('reg_no_seq')::text, 7, '0'),
                :registrationDate, :title, :firstName, :middleName, :lastName, :gender, :dateOfBirth, :ageYears,
                :bloodGroup, :maritalStatus, :nationality, :religion, :occupation, :nationalId, :preferredLanguage,
                :patientCategory, :status)
            RETURNING patient_id, registration_no
            """;

    private static final String INSERT_CONTACT = """
            INSERT INTO patient_contact (patient_id, mobile, alternate_phone, email, address_line1, address_line2,
                city, district, state, pincode, country, perm_same_as_current, permanent_address)
            VALUES (:patientId, :mobile, :alternatePhone, :email, :addressLine1, :addressLine2, :city, :district,
                :state, :pincode, :country, :permSameAsCurrent, :permanentAddress)
            """;

    private static final String INSERT_EMERGENCY = """
            INSERT INTO patient_emergency_contact (patient_id, contact_name, relationship, phone, alternate_phone, address)
            VALUES (:patientId, :emergencyName, :emergencyRelationship, :emergencyPhone, :emergencyAltPhone,
                :emergencyAddress)
            """;

    private static final String INSERT_INSURANCE = """
            INSERT INTO patient_insurance (patient_id, has_insurance, provider_name, policy_number, group_number,
                policy_holder_name, holder_relationship, valid_from, valid_to, coverage_type, sum_insured)
            VALUES (:patientId, :hasInsurance, :insuranceProvider, :policyNumber, :groupNumber, :policyHolderName,
                :holderRelationship, :policyValidFrom, :policyValidTo, :coverageType, :sumInsured)
            """;

    private static final String INSERT_MEDICAL = """
            INSERT INTO patient_medical_info (patient_id, height_cm, weight_kg, bmi, known_allergies,
                chronic_conditions, current_medications, past_surgeries, family_history, smoking_status,
                alcohol_use, disability, vaccination_status)
            VALUES (:patientId, :heightCm, :weightKg, :bmi, :knownAllergies, :chronicConditions,
                :currentMedications, :pastSurgeries, :familyHistory, :smokingStatus, :alcoholUse, :disability,
                :vaccinationStatus)
            """;

    private static final String INSERT_VISIT = """
            INSERT INTO patient_visit (patient_id, dept_id, consulting_doctor, visit_type, visit_date, referred_by,
                referral_source, chief_complaint, symptom_duration, priority, payment_mode, registration_fee, remarks,
                registration_visit)
            VALUES (:patientId, :deptId, :consultingDoctor, :visitType, :visitDate, :referredBy, :referralSource,
                :chiefComplaint, :symptomDuration, :priority, :paymentMode, :registrationFee, :remarks, TRUE)
            """;

    // Column aliases match PatientForm property names so BeanPropertyRowMapper can fill the whole form.
    private static final String SELECT_FULL = """
            SELECT p.*,
                   c.mobile, c.alternate_phone, c.email, c.address_line1, c.address_line2, c.city, c.district,
                   c.state, c.pincode, c.country, c.perm_same_as_current, c.permanent_address,
                   e.contact_name AS emergency_name, e.relationship AS emergency_relationship,
                   e.phone AS emergency_phone, e.alternate_phone AS emergency_alt_phone,
                   e.address AS emergency_address,
                   i.has_insurance, i.provider_name AS insurance_provider, i.policy_number, i.group_number,
                   i.policy_holder_name, i.holder_relationship, i.valid_from AS policy_valid_from,
                   i.valid_to AS policy_valid_to, i.coverage_type, i.sum_insured,
                   m.height_cm, m.weight_kg, m.bmi, m.known_allergies, m.chronic_conditions, m.current_medications,
                   m.past_surgeries, m.family_history, m.smoking_status, m.alcohol_use, m.disability,
                   m.vaccination_status,
                   v.dept_id, d.dept_name, v.consulting_doctor, v.visit_type, v.visit_date, v.referred_by,
                   v.referral_source, v.chief_complaint, v.symptom_duration, v.priority, v.payment_mode,
                   v.registration_fee, v.remarks
            FROM patient p
            LEFT JOIN patient_contact c ON c.patient_id = p.patient_id
            LEFT JOIN patient_emergency_contact e ON e.patient_id = p.patient_id
            LEFT JOIN patient_insurance i ON i.patient_id = p.patient_id
            LEFT JOIN patient_medical_info m ON m.patient_id = p.patient_id
            LEFT JOIN patient_visit v ON v.patient_id = p.patient_id AND v.registration_visit
            LEFT JOIN department d ON d.dept_id = v.dept_id
            WHERE p.patient_id = :id
            """;

    private final NamedParameterJdbcTemplate jdbc;

    public PatientDao(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /** Inserts into all six patient tables and publishes the outbox record. Caller must run this inside a transaction. */
    public void insert(PatientForm form) {
        Map<String, Object> keys = jdbc.queryForMap(INSERT_PATIENT, new BeanPropertySqlParameterSource(form));
        form.setPatientId(((Number) keys.get("patient_id")).longValue());
        form.setRegistrationNo((String) keys.get("registration_no"));

        SqlParameterSource params = new BeanPropertySqlParameterSource(form);
        jdbc.update(INSERT_CONTACT, params);
        jdbc.update(INSERT_EMERGENCY, params);
        jdbc.update(INSERT_INSURANCE, params);
        jdbc.update(INSERT_MEDICAL, params);
        jdbc.update(INSERT_VISIT, params);
        publishSnapshot(form.getPatientId());
    }

    /**
     * PatientSnapshot v1 (the published reporting contract) for one patient, in the caller's transaction.
     * The payload is built from v_patient_report, the same view the ClickHouse backfill reads, so both
     * paths produce identical records. Inserted and deleted at once: the outbox table stays empty, while
     * Debezium picks the insert up from the WAL (architecture section 13.3).
     */
    public void publishSnapshot(long patientId) {
        // Two statements: a DELETE cannot see rows inserted by a WITH clause of the same statement.
        List<Long> ids = jdbc.queryForList(PUBLISH_SNAPSHOT, new MapSqlParameterSource("id", patientId), Long.class);
        if (!ids.isEmpty()) {
            jdbc.update("DELETE FROM report_outbox WHERE id IN (:ids)", new MapSqlParameterSource("ids", ids));
        }
    }

    private static final String PUBLISH_SNAPSHOT = """
            INSERT INTO report_outbox (aggregatetype, aggregateid, type, payload)
            SELECT 'patient', v.patient_id::text, 'PatientSnapshot.v1',
                   to_jsonb(v) || jsonb_build_object('source_ts', to_char(v.source_ts, 'YYYY-MM-DD HH24:MI:SS.MS'))
            FROM v_patient_report v
            WHERE v.patient_id = :id
            RETURNING id
            """;

    public PatientForm findById(long patientId) {
        BeanPropertyRowMapper<PatientForm> mapper = new BeanPropertyRowMapper<>(PatientForm.class);
        mapper.setPrimitivesDefaultedForNullValue(true);
        List<PatientForm> list = jdbc.query(SELECT_FULL, new MapSqlParameterSource("id", patientId), mapper);
        return list.isEmpty() ? null : list.getFirst();
    }

    public List<Department> findActiveDepartments() {
        return jdbc.query("SELECT dept_id, dept_code, dept_name FROM department WHERE active ORDER BY dept_name",
                (rs, i) -> new Department(rs.getInt(1), rs.getString(2), rs.getString(3)));
    }

    public String findDepartmentName(Integer deptId) {
        if (deptId == null) return null;
        List<String> names = jdbc.queryForList("SELECT dept_name FROM department WHERE dept_id = :id",
                new MapSqlParameterSource("id", deptId), String.class);
        return names.isEmpty() ? null : names.getFirst();
    }

    /** Dashboard figures: total patients, registered today, registered this month. */
    public Map<String, Object> dashboardCounts() {
        return jdbc.queryForMap("""
                SELECT count(*) AS total,
                       count(*) FILTER (WHERE registration_date = CURRENT_DATE) AS today,
                       count(*) FILTER (WHERE registration_date >= date_trunc('month', CURRENT_DATE)) AS month
                FROM patient
                """, Map.of());
    }
}
