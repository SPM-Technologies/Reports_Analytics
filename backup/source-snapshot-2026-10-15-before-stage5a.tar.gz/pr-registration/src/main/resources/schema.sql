-- Patient Registration schema (PostgreSQL). Safe to run repeatedly.
CREATE SCHEMA IF NOT EXISTS patientreg;
SET search_path TO patientreg;

CREATE SEQUENCE IF NOT EXISTS reg_no_seq START 1;

-- 1. Department master
CREATE TABLE IF NOT EXISTS department (
    dept_id     SERIAL PRIMARY KEY,
    dept_code   VARCHAR(10)  NOT NULL UNIQUE,
    dept_name   VARCHAR(100) NOT NULL,
    active      BOOLEAN      NOT NULL DEFAULT TRUE
);

-- 2. Patient (core demographics)
CREATE TABLE IF NOT EXISTS patient (
    patient_id          BIGSERIAL PRIMARY KEY,
    registration_no     VARCHAR(20)  NOT NULL UNIQUE,
    registration_date   DATE         NOT NULL DEFAULT CURRENT_DATE,
    title               VARCHAR(10),
    first_name          VARCHAR(60)  NOT NULL,
    middle_name         VARCHAR(60),
    last_name           VARCHAR(60)  NOT NULL,
    gender              VARCHAR(10)  NOT NULL,
    date_of_birth       DATE,
    age_years           INTEGER      NOT NULL,
    blood_group         VARCHAR(5),
    marital_status      VARCHAR(15),
    nationality         VARCHAR(40),
    religion            VARCHAR(30),
    occupation          VARCHAR(60),
    national_id         VARCHAR(20),
    preferred_language  VARCHAR(30),
    patient_category    VARCHAR(20)  NOT NULL DEFAULT 'GENERAL',
    status              VARCHAR(10)  NOT NULL DEFAULT 'ACTIVE',
    created_at          TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP
);
-- matches the register's sort order, so page 1 and date filters read the index in order
DROP INDEX IF EXISTS idx_patient_reg_date;
CREATE INDEX IF NOT EXISTS idx_patient_reg_order ON patient (registration_date DESC, patient_id DESC);
CREATE INDEX IF NOT EXISTS idx_patient_gender   ON patient (gender);
CREATE INDEX IF NOT EXISTS idx_patient_category ON patient (patient_category);

-- 3. Contact & address (1:1)
CREATE TABLE IF NOT EXISTS patient_contact (
    patient_id            BIGINT PRIMARY KEY REFERENCES patient (patient_id) ON DELETE CASCADE,
    mobile                VARCHAR(15) NOT NULL,
    alternate_phone       VARCHAR(15),
    email                 VARCHAR(100),
    address_line1         VARCHAR(150) NOT NULL,
    address_line2         VARCHAR(150),
    city                  VARCHAR(60)  NOT NULL,
    district              VARCHAR(60),
    state                 VARCHAR(60)  NOT NULL,
    pincode               VARCHAR(10)  NOT NULL,
    country               VARCHAR(60)  NOT NULL DEFAULT 'India',
    perm_same_as_current  BOOLEAN      NOT NULL DEFAULT TRUE,
    permanent_address     VARCHAR(300)
);
CREATE INDEX IF NOT EXISTS idx_contact_mobile ON patient_contact (mobile);
CREATE INDEX IF NOT EXISTS idx_contact_city   ON patient_contact (city);

-- 4. Emergency contact (1:1)
CREATE TABLE IF NOT EXISTS patient_emergency_contact (
    patient_id       BIGINT PRIMARY KEY REFERENCES patient (patient_id) ON DELETE CASCADE,
    contact_name     VARCHAR(100) NOT NULL,
    relationship     VARCHAR(30)  NOT NULL,
    phone            VARCHAR(15)  NOT NULL,
    alternate_phone  VARCHAR(15),
    address          VARCHAR(300)
);

-- 5. Insurance (1:1)
CREATE TABLE IF NOT EXISTS patient_insurance (
    patient_id           BIGINT PRIMARY KEY REFERENCES patient (patient_id) ON DELETE CASCADE,
    has_insurance        BOOLEAN NOT NULL DEFAULT FALSE,
    provider_name        VARCHAR(100),
    policy_number        VARCHAR(40),
    group_number         VARCHAR(40),
    policy_holder_name   VARCHAR(100),
    holder_relationship  VARCHAR(30),
    valid_from           DATE,
    valid_to             DATE,
    coverage_type        VARCHAR(30),
    sum_insured          NUMERIC(12, 2)
);

-- 6. Medical information (1:1)
CREATE TABLE IF NOT EXISTS patient_medical_info (
    patient_id           BIGINT PRIMARY KEY REFERENCES patient (patient_id) ON DELETE CASCADE,
    height_cm            NUMERIC(5, 1),
    weight_kg            NUMERIC(5, 1),
    bmi                  NUMERIC(5, 1),
    known_allergies      VARCHAR(300),
    chronic_conditions   VARCHAR(300),
    current_medications  VARCHAR(300),
    past_surgeries       VARCHAR(300),
    family_history       VARCHAR(300),
    smoking_status       VARCHAR(20),
    alcohol_use          VARCHAR(20),
    disability           VARCHAR(100),
    vaccination_status   VARCHAR(30)
);

-- 7. Visit (1:N, first visit created at registration)
CREATE TABLE IF NOT EXISTS patient_visit (
    visit_id            BIGSERIAL PRIMARY KEY,
    patient_id          BIGINT  NOT NULL REFERENCES patient (patient_id) ON DELETE CASCADE,
    dept_id             INTEGER NOT NULL REFERENCES department (dept_id),
    consulting_doctor   VARCHAR(100) NOT NULL,
    visit_type          VARCHAR(20)  NOT NULL,
    visit_date          DATE         NOT NULL,
    referred_by         VARCHAR(100),
    referral_source     VARCHAR(30),
    chief_complaint     VARCHAR(300) NOT NULL,
    symptom_duration    VARCHAR(30),
    priority            VARCHAR(10)  NOT NULL DEFAULT 'NORMAL',
    payment_mode        VARCHAR(20)  NOT NULL,
    registration_fee    NUMERIC(10, 2) NOT NULL DEFAULT 0,
    remarks             VARCHAR(300)
);
CREATE INDEX IF NOT EXISTS idx_visit_patient ON patient_visit (patient_id);
CREATE INDEX IF NOT EXISTS idx_visit_dept    ON patient_visit (dept_id);
CREATE INDEX IF NOT EXISTS idx_visit_date    ON patient_visit (visit_date);

-- Phase 2: flag the visit created at registration so reports use a plain join
-- instead of looking up each patient's first visit row by row.
ALTER TABLE patient_visit ADD COLUMN IF NOT EXISTS registration_visit BOOLEAN NOT NULL DEFAULT FALSE;
UPDATE patient_visit SET registration_visit = TRUE
WHERE visit_id IN (SELECT min(visit_id) FROM patient_visit GROUP BY patient_id
                   HAVING NOT bool_or(registration_visit));
CREATE UNIQUE INDEX IF NOT EXISTS ux_visit_registration ON patient_visit (patient_id) WHERE registration_visit;

-- Phase 2: trigram indexes so "contains" search on name / reg no / mobile avoids full scans.
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE INDEX IF NOT EXISTS idx_patient_name_trgm ON patient
    USING gin ((first_name || ' ' || last_name) gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_patient_regno_trgm ON patient USING gin (registration_no gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_contact_mobile_trgm ON patient_contact USING gin (mobile gin_trgm_ops);

-- Department seed data
INSERT INTO department (dept_code, dept_name) VALUES
    ('GEN', 'General Medicine'),
    ('CAR', 'Cardiology'),
    ('ORT', 'Orthopaedics'),
    ('PED', 'Paediatrics'),
    ('GYN', 'Obstetrics & Gynaecology'),
    ('ENT', 'ENT'),
    ('DER', 'Dermatology'),
    ('NEU', 'Neurology'),
    ('OPH', 'Ophthalmology'),
    ('DEN', 'Dental')
ON CONFLICT (dept_code) DO NOTHING;

-- Reporting stage 2: published contract for the analytics store (PatientSnapshot v1).
-- row_version increases on every change of a patient; the analytics table keeps the highest version.
ALTER TABLE patient ADD COLUMN IF NOT EXISTS row_version BIGINT NOT NULL DEFAULT 1;
CREATE INDEX IF NOT EXISTS idx_patient_change_ts ON patient ((coalesce(updated_at, created_at)));

-- Flattened, minimised record per patient (no Aadhaar, masked mobile, no free-text health data).
-- Read by ClickHouse (backfill and, until CDC in stage 4, a one-minute incremental copy).
CREATE OR REPLACE VIEW v_patient_report AS
SELECT p.patient_id,
       p.registration_no,
       p.registration_date,
       concat_ws(' ', p.title, p.first_name, p.middle_name, p.last_name) AS patient_name,
       p.gender,
       p.age_years,
       CASE WHEN p.age_years < 14 THEN '0-13' WHEN p.age_years < 25 THEN '14-24'
            WHEN p.age_years < 45 THEN '25-44' WHEN p.age_years < 60 THEN '45-59' ELSE '60+' END AS age_band,
       p.patient_category,
       coalesce(p.blood_group, '') AS blood_group,
       coalesce(p.marital_status, '') AS marital_status,
       c.city,
       coalesce(c.district, '') AS district,
       c.state,
       left(c.mobile, 2) || 'XXXXXX' || right(c.mobile, 2) AS mobile_masked,
       v.dept_id,
       d.dept_name,
       v.consulting_doctor,
       v.visit_type,
       v.priority,
       coalesce(v.referral_source, '') AS referral_source,
       v.payment_mode,
       v.registration_fee,
       CASE WHEN i.has_insurance THEN 1 ELSE 0 END AS is_insured,
       coalesce(i.coverage_type, '') AS coverage_type,
       coalesce(i.provider_name, '') AS insurance_provider,
       p.row_version AS version,
       0 AS is_deleted,
       coalesce(p.updated_at, p.created_at) AS source_ts
FROM patient p
JOIN patient_contact c ON c.patient_id = p.patient_id
JOIN patient_visit v ON v.patient_id = p.patient_id AND v.registration_visit
JOIN department d ON d.dept_id = v.dept_id
LEFT JOIN patient_insurance i ON i.patient_id = p.patient_id;

-- Reporting stage 4: transactional outbox (architecture D7, section 13.3). Every save inserts a
-- PatientSnapshot v1 record here and deletes it in the same transaction: the table stays empty, but
-- both changes are in the WAL, where Debezium reads the insert (a publication covers only this table).
CREATE TABLE IF NOT EXISTS report_outbox (
    id             BIGSERIAL PRIMARY KEY,
    aggregatetype  VARCHAR(40)  NOT NULL,
    aggregateid    VARCHAR(40)  NOT NULL,
    type           VARCHAR(60)  NOT NULL,
    payload        JSONB        NOT NULL,
    created_at     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Debezium updates this row periodically (heartbeat.action.query) so the replication slot keeps
-- advancing while the outbox is quiet; no data of interest lives here.
CREATE TABLE IF NOT EXISTS cdc_heartbeat (
    id  INTEGER PRIMARY KEY,
    ts  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO cdc_heartbeat (id) VALUES (1) ON CONFLICT (id) DO NOTHING;
