# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

Spring MVC 6.2 (plain Java config, no Spring Boot, no ORM) + JSP patient registration app on Java 21 / Tomcat 11, PostgreSQL 18 in Docker. A 70-field registration form is stored across 6 tables plus a `department` master; two reports (patient register, department summary) render on screen and download as Excel (Apache POI) or PDF (OpenPDF). The DB holds ~1 lakh generated patients (Phase 2). Full human-facing documentation: `Docs/Patient-Registration-Project-Guide.html` — keep it in sync when behaviour, schema, config or counts change. The approved target design for the new reporting module (ClickHouse + CDC, React UI in the same WAR) is `Docs/Solution-Architecture.html` (v2.1); development follows its roadmap stages (0–4 done). Next: stage 5a login + multi-hospital isolation (section 10.1 / D13), then 5b full customisation — admin-defined custom fields, per-field reportable/sensitivity, calculated fields via a safe formula language (section 10.2 / D14) (hospital_id on every row, per-hospital registration numbers and departments, users with several hospitals, PostgreSQL row-level security + forced hospital filter in QueryBuilder).

## Environment (local Windows machine)

- **Everything runs in Docker** (`docker-compose.yml`, project `patient-registration`): `pr-postgres`, `pr-clickhouse`, `pr-app` (Tomcat 11 + WAR built by the root `Dockerfile`), one-shot `pg-setup` / `analytics-setup`; profile `cdc` adds `pr-kafka`, `pr-debezium`, `ch-cdc-setup`, `cdc-setup`; profile `seed` adds `seed`, `seed-backfill`. Passwords in root `.env`. App at http://localhost:8080/patient-registration/. The user wants the project shareable with nothing installed but Docker.
- The pre-Docker containers `Postgres` (postgres:latest) and `pr-clickhouse-old` are stopped and kept (user decision: stop, not delete). Host Tomcat `D:\Pravin\apache-tomcat-11.0.27` is no longer used (port 8080 belongs to `pr-app`).
- For host builds/tests: JDK `D:\Pravin\jdk-21.0.12.1` (not on PATH; `JAVA_HOME` in the shell points elsewhere — always set it); Maven 3.9.9 and its local repo are bundled in `tools\` (`tools\apache-maven-3.9.9`, `tools\m2repo`). Do not use `D:\Pravin\apache-maven-3.10.0`.
- PostgreSQL: db `postgres`, schema `patientreg`; settings in `pr-registration/src/main/resources/db.properties`, overridden in the container by env vars (`DB_URL` -> `db.url`, `APP_REPORTING_CLICKHOUSE_URL` -> `app.reporting.clickhouse.url`; Spring's system-environment property source wins over `@PropertySource`). Tests use database `prtest` (`pr-app/src/test/resources/db.properties`) and ClickHouse `analytics_test`, via localhost ports.
- Low-RAM machine (7.7 GB, Docker ~3.9 GB): every service has `mem_limit`; `MAVEN_OPTS=-Xmx512m`. The user asked not to run load tests for now.

## Commands

Scripts: `start.bat [cdc]`, `stop.bat`, `deploy.bat` (rebuild app image), `load-data.bat [rows]`, `backup.bat` wrap docker compose; `build.bat`, `test.bat` run host Maven. From the Bash tool (run .bat files as `cmd //c "D:\\Pravin\\patient-registration\\x.bat"`; a relative name is not found):

```bash
# whole system / real-time pipeline / redeploy app after code change
docker compose up -d --build
docker compose --profile cdc up -d --build
docker compose up -d --build app
docker compose logs -f app
curl -s http://localhost:8083/connectors/patient-outbox/status          # Debezium connector (cdc)

# build (add -o for offline once plugins are cached; `clean` needs the clean plugin downloaded once)
cd /d/Pravin/patient-registration && JAVA_HOME="D:/Pravin/jdk-21.0.12.1" \
  ./tools/apache-maven-3.9.9/bin/mvn -q -B -Dmaven.repo.local="D:/Pravin/patient-registration/tools/m2repo" clean package
# (package runs the tests too; add -DskipTests to skip)

# tests: all, one module, or one class
mvn ... test
mvn ... -pl pr-registration test
mvn ... -pl pr-app -am -Dtest=WebSmokeTest -Dsurefire.failIfNoSpecifiedTests=false test

# ClickHouse (admin user "admin", password in .env)
bash infra/clickhouse-schema.sh                     # idempotent DDL into analytics + analytics_test
docker exec -i pr-clickhouse clickhouse-client --user admin --password ChAdmin@1234 --multiquery < infra/clickhouse/pipeline/backfill.sql
docker exec pr-clickhouse clickhouse-client --user admin --password ChAdmin@1234 -q "select count() from analytics.patient_report FINAL"

# React UI (pr-ui): built by Maven via frontend-maven-plugin (Node in tools/node). For fast UI work:
cd pr-ui && PATH="/d/Pravin/patient-registration/tools/node:$PATH" npm run dev     # proxies /api to localhost:8080
# browser end-to-end tests (Playwright, installed Edge; pr-app must run the current code; expect 1,00,002 patients)
cd pr-ui && PATH="/d/Pravin/patient-registration/tools/node:$PATH" npx playwright test

# DB access
docker exec pr-postgres psql -U postgres -c "select count(*) from patientreg.patient"

# bulk data (adds rows; then reload ClickHouse) and full backup
SEED_ROWS=100000 docker compose --profile seed up seed seed-backfill
docker exec pr-postgres pg_dump -U postgres -d postgres -n patientreg -n reporting --extension=pg_trgm -Fc -Z 6 > backup/patientreg_full_YYYY-MM-DD.dump
# restore into an empty database: pg_restore --no-owner --no-acl (grants come from pg-setup), then docker compose up analytics-setup
```

Tests (JUnit 5, AssertJ, Spring MockMvc, ArchUnit) need the `pr-postgres` and `pr-clickhouse` containers running and use the `prtest` (Postgres) and `analytics_test` (ClickHouse) databases. `ReportingApiTest` seeds `analytics_test` itself. `WebSmokeTest` boots the real `RootConfig` + `WebConfig` and hits every screen and download, but MockMvc does not render JSPs, so after UI changes also deploy and check pages with `curl`. No linter.

## Architecture (big picture)

- **Modular monolith, one WAR.** Maven modules: `pr-shared` (export writers `ExcelExporter`/`PdfExporter`/`ReportDefinition`, `ExportLimiter`), `pr-registration` (all existing feature code, packages `com.hospital.patientreg.registration.{config,web,service,dao,model}`, plus `db.properties`/`schema.sql`), `pr-reporting` (new read side: `semantic` dataset catalogue from `reporting/datasets/*.json`, `query` builder/service on a read-only ClickHouse pool, `api` REST controller at `/api/v1` + problem+json advice), `pr-ui` (React + TypeScript + Vite report builder; `npm run build` = `tsc --noEmit && vite build` into `target/classes/META-INF/resources/app`), `pr-app` (war: `WebAppInitializer`, `RootConfig`, `WebConfig`, JSPs/CSS/JS, `web.xml`, `messages.properties`; copies the pr-ui build into the WAR as plain files under `/app`). Registration and reporting must never depend on each other (Maven deps + `ArchitectureTest` enforce it); only `pr-app` sees all modules.
- **Two Spring contexts.** `WebAppInitializer` boots root `RootConfig` (imports `SharedConfig`, `RegistrationConfig`, `ReportingConfig`; each scans only its own non-web packages) and servlet `WebConfig` (MVC, JSP resolver, `messageSource`; scans `registration.web` and `reporting.api` for controllers/advice only). New controllers must live in a module's web/api package. `RegistrationConfig` marks the OLTP DataSource, JDBC templates and transaction manager `@Primary`, so a second data source (ClickHouse, stage 2) never makes by-type injection ambiguous.
- **Schema is applied at every startup** by `DataSourceInitializer` running `pr-registration/src/main/resources/schema.sql`. It must stay idempotent (`IF NOT EXISTS`, `ADD COLUMN IF NOT EXISTS`, `ON CONFLICT DO NOTHING`). `ResourceDatabasePopulator` splits on `;`, so no `DO $$ … $$` blocks. This is the only migration mechanism.
- **One flat form bean, six tables.** `PatientForm` holds all fields; `PatientDao.insert` writes `patient` (generating `registration_no` = `REG` + year + 7-digit `reg_no_seq` inside the INSERT) then the five child tables in one `@Transactional` `PatientService.register`. `PatientDao.SELECT_FULL` reads it back with `BeanPropertyRowMapper`, relying on column aliases that match `PatientForm` property names.
- **Registration visit invariant.** `patient_visit.registration_visit = TRUE` marks the visit created at registration (partial unique index `ux_visit_registration`). All report SQL joins on this flag (`ReportDao.REGISTER_FROM`) instead of finding the first visit — new inserts must set it.
- **Reports.** `ReportDao` has one shared FROM + dynamically built WHERE (constant fragments, bound params) used by count, page (`LIMIT/OFFSET`, 50 rows, `registration_date DESC, patient_id DESC`), streaming export, and the department summary. Row arrays are positional: on-screen rows have `patient_id` at index 0, export rows do not; `ReportService` holds the header/width arrays that must match.
- **Exports stream.** `ReportService.export*` is `@Transactional(readOnly)` so PgJDBC uses a cursor (fetch size 2000); `ExcelExporter` uses SXSSF (200-row window) and `PdfExporter` flushes an incomplete `PdfPTable` every 500 rows, both fed by `ReportDefinition`'s row-consumer. `ReportController` runs exports through `ExportLimiter` (semaphore, `export.maxConcurrent`, 20 s wait → 503) and sets download headers *inside* the limiter so a "busy" reply is not saved as a file.
- **React app at `/app`** is served by `WebConfig` resource handlers (WAR folder first, classpath fallback for tests); unknown routes get `index.html`, missing assets 404, `/app/` is a forward. It talks only to `/api/v1` (same origin, same session). Saved reports live in PostgreSQL schema `reporting` (pr-reporting's own small pool, `reporting-schema.sql`, templates upserted at startup). Downloads (`POST /api/v1/query/export`) run through the shared `ExportLimiter` and validate + count before writing headers (PDF max 50,000 rows, Excel 10 lakh, CSV 20 lakh).
- **Errors.** `GlobalExceptionHandler` (scoped to `registration.web`) renders `error.jsp`; only `ResponseStatusException` reasons are shown to users. Unmapped URLs fall through to the container error page (same `error.jsp`). The reporting API needs its own JSON (problem+json) advice.

## Rules that span several files

- **Reporting data flow (stage 2).** Registration publishes `patientreg.v_patient_report` (PatientSnapshot v1, in `schema.sql`; no Aadhaar, masked mobile, `version` = `patient.row_version`). ClickHouse `analytics.patient_report` (ReplacingMergeTree(version, is_deleted), DDL in `infra/clickhouse/schema/`) is filled by `infra/clickhouse/pipeline/backfill.sql` and kept fresh by the refreshable MV `mv_patient_report_sync` (every minute, last 15 minutes via `postgresql()`, WHERE pushed down). Adding a report field = the view + the ClickHouse DDL + both pipeline column lists + `patients.json`. Deletes and SQL-script writes are NOT propagated (neither path sees them): backfill or delete in ClickHouse manually.
- **Real-time path (stage 4, profile `cdc`).** `PatientDao.publishSnapshot` inserts the `v_patient_report` row as JSON into `report_outbox` and deletes it in the same transaction (table stays empty; Debezium reads the INSERT from the WAL via publication `pr_outbox_pub`, slot `pr_outbox_slot`). Connector config `infra/debezium/patient-outbox.json` (EventRouter -> topic `pr.patient.report`, key = patient id); ClickHouse Kafka engine + MVs in `infra/clickhouse/pipeline/020_realtime_kafka.sql` (errors -> `pipeline_errors`, heartbeats -> `pipeline_heartbeat`, used by `QueryService.dataAsOf`). Any new write path to patients must call `publishSnapshot`. `OutboxContractTest` checks the WAL event with a `test_decoding` slot. The one-minute sync keeps running in cdc mode as a safety net (duplicates collapse via ReplacingMergeTree/FINAL).
- **Reporting queries** are built only by `QueryBuilder`: field/operator/aggregation whitelisted by the catalogue, identifiers from the validated catalogue only, values always bound, `FINAL` + `is_deleted = 0` always, relative dates in IST. Never concatenate request values into SQL. The app ClickHouse account is read-only; DDL is applied by the admin via `infra/clickhouse-schema.sh`.

- **Adding/changing a form field** touches: `schema.sql`, `PatientForm`, `PatientDao` (INSERT and `SELECT_FULL` alias), `PatientValidator` (`MAX_LENGTHS` must equal the column size; dropdowns go in `SELECT_FIELDS` + `model/Lookups`), `patient-form.jsp` (every field has a `<form:errors>`), `patient-view.jsp`, `db/load-test-data.sql` (it fills every column), and the HTML guide.
- **Server-side validation is authoritative**: dropdown values are whitelisted against `Lookups`, text lengths and numeric ranges are checked so nothing reaches the DB as a 500. `PatientController` disallows binding `patientId, registrationNo, status, bmi, deptName`.
- **JSP escaping**: user data must be output via `<c:out>` or Spring form tags; raw `${}` is only used for server-generated values. Every JSP starts with `<%@ include file="common/taglibs.jspf" %>` before using tags, then sets `pageTitle`/`activeNav` and includes `header.jspf`.
- Search uses `pg_trgm` GIN indexes (`first_name || ' ' || last_name`, `registration_no`, `mobile`); keep the WHERE expressions identical to the index expressions, and keep LIKE-wildcard escaping in `ReportDao`.

## Gotchas found in this environment

- Windows reports time zone `Asia/Calcutta`, which the Postgres container rejects at login; `RegistrationConfig`'s static block switches the JVM default to `Asia/Kolkata`.
- `slf4j-api` and `log4j-api` are pinned in the parent `pom.xml` (dependencyManagement); a transitive `slf4j-api` 1.7 silently turns all logging into a no-op.
- Editing a file with a shell command (sed/perl) and then using the Write tool on it fails with "modified since read"; Read it first. Beware `	` in Windows paths inside perl/sed replacements.
- Running `.bat` files via the PowerShell tool has repeatedly failed to write files and the `.bat` files themselves disappeared afterwards (`deploy.bat`, `load-data.bat`, `backup.bat`). Prefer the Bash tool with direct commands; recreate scripts from the HTML guide if missing.
- `pg_dump -n patientreg` alone omits the `pg_trgm` extension and the dump will not restore; always add `--extension=pg_trgm`.
- Never serve static files from inside a jar in `WEB-INF/lib` on Windows: Tomcat keeps the jar locked and hot redeploys then leave a half-deployed app (404s). That is why pr-ui is `provided` and copied into the WAR.
- Headless Edge under Playwright crashes when a real download completes; e2e tests record the save (`recordSaves`) and read the blob instead.
- Docker's default 64 MB `/dev/shm` made 20 concurrent legacy report scans fail ("could not resize shared memory segment"); `pr-postgres` has `shm_size: 256mb`.
- The ClickHouse admin created from `CLICKHOUSE_USER` cannot use the `pg_reporting` named collection without `named_collection_control` (`infra/clickhouse/users.d/admin-named-collections.xml`).
- The ClickHouse image has no `curl`; the connector is registered from the Debezium image (`cdc-setup`). quay.io pulls sometimes fail with "server gave HTTP response to HTTPS client": just retry.
- In compose `command` blocks, `$` must be written `$$`; values with `@` in passwords are fine.
- Restoring a dump taken from the old container needs `pg_restore --no-owner --no-acl` (roles are created later by `pg-setup`).
- Right after ClickHouse restarts, the first JDBC test classes may time out ("Read timed out"); re-run.
- The interim one-minute ClickHouse sync looks back 15 minutes: after a longer ClickHouse outage run the backfill.
- ClickHouse data cannot live on a Windows bind mount (part-directory rename fails with "Permission denied", even as root); it uses a Docker volume (inside Docker's disk image on C:). Moving Docker Desktop's disk image to D: is the way to get it onto D:.
- The ClickHouse JDBC driver refuses to make a read-only account's connection read-write, so the Hikari pool must be `setReadOnly(true)` or no connection is ever created.
- Plain Spring (no Boot) serialises `LocalDate` as arrays unless `WRITE_DATES_AS_TIMESTAMPS` is disabled (`WebConfig.extendMessageConverters`).
- ClickHouse low-memory config: `background_pool_size` 4 requires lowering the merge-tree `number_of_free_entries_in_pool_*` thresholds or the server refuses to start.
- The 1-lakh generated data has some `created_at` values later today (future), so `QueryService.dataAsOf` caps the newest change at the current time.
- Sequences are not rolled back: failed saves or aborted loads leave gaps in `reg_no_seq`/`patient_patient_id_seq`.
- Known open item: a non-numeric `/patient/{id}` returns 500 instead of 400.
- Deliberately out of scope (user decision): authentication/CSRF, and Unicode fonts for PDF (non-Latin text prints as `???`).
