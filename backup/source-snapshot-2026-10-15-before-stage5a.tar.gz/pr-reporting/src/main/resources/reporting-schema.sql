-- Reporting module metadata in PostgreSQL (its own schema; never the registration tables).
-- Applied at every startup through the reporting metadata pool; must stay idempotent
-- (ResourceDatabasePopulator splits on ';', so no DO blocks and no ';' inside the JSON).
CREATE SCHEMA IF NOT EXISTS reporting;

CREATE TABLE IF NOT EXISTS reporting.saved_report (
    id            BIGSERIAL PRIMARY KEY,
    name          VARCHAR(120) NOT NULL,
    description   VARCHAR(400),
    definition    TEXT         NOT NULL,          -- {"query": <report definition>, "view": <screen settings>}
    template_key  VARCHAR(40)  UNIQUE,            -- set only for built-in templates (read-only)
    created_at    TIMESTAMP    NOT NULL DEFAULT now(),
    updated_at    TIMESTAMP    NOT NULL DEFAULT now()
);

-- Built-in templates: today's Report 1 and Report 2 plus two starter views. Kept in sync with the code.
INSERT INTO reporting.saved_report (template_key, name, description, definition) VALUES
('patient-register', 'Patient Register (Report 1)', 'Registered patients, newest first - the classic register list.',
 '{"query":{"dataset":"patients","columns":["registration_no","registration_date","patient_name","gender","age_years","mobile_masked","city","state","dept_name","consulting_doctor","visit_type","patient_category","is_insured","registration_fee"],"pageSize":50},"view":{"mode":"table"}}'),
('department-summary', 'Department Summary (Report 2)', 'Patients, insured patients, average age and fees per department.',
 '{"query":{"dataset":"patients","columns":["dept_name"],"measures":[{"field":"patients"},{"field":"is_insured","agg":"sum"},{"field":"age_years","agg":"avg"},{"field":"registration_fee","agg":"sum"}],"sort":[{"field":"dept_name","dir":"asc"}],"pageSize":50},"view":{"mode":"table"}}'),
('department-gender', 'Patients by Department and Gender', 'Head-count per department split by gender.',
 '{"query":{"dataset":"patients","columns":["dept_name","gender"],"measures":[{"field":"patients"}],"sort":[{"field":"dept_name","dir":"asc"},{"field":"gender","dir":"asc"}],"pageSize":100},"view":{"mode":"chart","chart":"bar"}}'),
('monthly-trend', 'Monthly Registrations', 'Registrations and fees month by month.',
 '{"query":{"dataset":"patients","columns":["registration_month"],"measures":[{"field":"patients"},{"field":"registration_fee","agg":"sum"}],"sort":[{"field":"registration_month","dir":"asc"}],"pageSize":100},"view":{"mode":"chart","chart":"line"}}')
ON CONFLICT (template_key) DO UPDATE
    SET name = EXCLUDED.name, description = EXCLUDED.description, definition = EXCLUDED.definition, updated_at = now();
