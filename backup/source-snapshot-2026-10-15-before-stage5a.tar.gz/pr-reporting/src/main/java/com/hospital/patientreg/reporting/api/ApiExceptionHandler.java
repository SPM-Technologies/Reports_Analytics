package com.hospital.patientreg.reporting.api;

import com.hospital.patientreg.reporting.query.InvalidQueryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * JSON errors (RFC 9457 problem+json) for the reporting API only. JSP controllers keep their
 * HTML error page (registration module's GlobalExceptionHandler is scoped to its own package).
 */
@RestControllerAdvice(basePackages = "com.hospital.patientreg.reporting.api")
public class ApiExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(ApiExceptionHandler.class);

    @ExceptionHandler(InvalidQueryException.class)
    public ProblemDetail invalidQuery(InvalidQueryException ex) {
        return problem(HttpStatus.BAD_REQUEST, "Invalid report definition", ex.getMessage());
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ProblemDetail unreadable(HttpMessageNotReadableException ex) {
        return problem(HttpStatus.BAD_REQUEST, "Invalid request", "The request body is not a valid report definition.");
    }

    @ExceptionHandler(DataAccessException.class)
    public ProblemDetail analyticsUnavailable(DataAccessException ex) {
        log.error("Analytics query failed", ex);
        return problem(HttpStatus.SERVICE_UNAVAILABLE, "Reports temporarily unavailable",
                "The reporting database did not answer. Please try again shortly.");
    }

    @ExceptionHandler(Exception.class)
    public ProblemDetail unexpected(Exception ex) {
        if (ex instanceof ErrorResponse er) {   // Spring MVC request errors keep their own status (400, 405, ...)
            return er.getBody();
        }
        log.error("Reporting API request failed", ex);
        return problem(HttpStatus.INTERNAL_SERVER_ERROR, "Unexpected error",
                "Something went wrong while running the report.");
    }

    private static ProblemDetail problem(HttpStatus status, String title, String detail) {
        ProblemDetail pd = ProblemDetail.forStatusAndDetail(status, detail);
        pd.setTitle(title);
        return pd;
    }
}
