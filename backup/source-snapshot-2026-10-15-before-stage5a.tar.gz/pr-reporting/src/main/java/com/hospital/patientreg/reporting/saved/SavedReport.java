package com.hospital.patientreg.reporting.saved;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.JsonNode;
import java.time.LocalDateTime;

/**
 * A saved report: name, description and definition ({"query": ..., "view": ...}).
 * Built-in templates have {@code template = true} and are read-only.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public record SavedReport(
        Long id,
        String name,
        String description,
        boolean template,
        LocalDateTime updatedAt,
        JsonNode definition) {
}
