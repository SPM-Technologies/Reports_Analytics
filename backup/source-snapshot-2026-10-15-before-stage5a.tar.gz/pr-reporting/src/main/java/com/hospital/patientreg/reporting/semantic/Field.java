package com.hospital.patientreg.reporting.semantic;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.List;

/**
 * One field of a dataset. {@code role} is "dimension" (can be shown, filtered, grouped and, if it lists
 * {@code aggregations}, aggregated) or "measure" (a fixed aggregate {@code expression}, e.g. count()).
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_DEFAULT)
public record Field(
        String name,
        String label,
        FieldType type,
        String role,
        List<String> aggregations,
        Integer scale,
        String expression,
        boolean suggest,
        boolean hidden,
        String sensitivity) {

    public boolean isMeasure() {
        return "measure".equals(role);
    }

    public boolean allowsAggregation(String agg) {
        return aggregations != null && aggregations.contains(agg);
    }
}
