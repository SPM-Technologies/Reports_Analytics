package com.hospital.patientreg.reporting.query;

import java.util.List;
import java.util.Map;

/**
 * Validated, parameterised SQL for one report definition. {@code totalsSql} is null for detail lists.
 * All user values are in {@code params}; the SQL text contains only catalogue identifiers.
 */
public record QueryPlan(
        String mode,
        List<OutputColumn> columns,
        String dataSql,
        String countSql,
        String totalsSql,
        Map<String, Object> params,
        int pageSize,
        int offset) {

    /** A column of the result: a field shown/grouped, or a computed measure. */
    public record OutputColumn(String key, String label, String type, String role) {
    }
}
