package com.hospital.patientreg.reporting.query;

import com.hospital.patientreg.reporting.query.QueryPlan.OutputColumn;
import com.hospital.patientreg.reporting.query.QueryRequest.MeasureSpec;
import com.hospital.patientreg.reporting.query.QueryRequest.SortSpec;
import com.hospital.patientreg.reporting.semantic.Dataset;
import com.hospital.patientreg.reporting.semantic.Field;
import com.hospital.patientreg.reporting.semantic.FieldType;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Turns a report definition into validated, parameterised ClickHouse SQL.
 * <ul>
 *   <li>Only identifiers from the (validated) catalogue are written into SQL; every user value is a bound parameter.</li>
 *   <li>Every query reads {@code FINAL} (latest version per patient) and skips deleted rows.</li>
 *   <li>Relative dates are computed in the application's time zone (IST).</li>
 * </ul>
 */
@Component
public class QueryBuilder {

    private static final int MAX_COLUMNS = 40;
    private static final int MAX_GROUP_BY = 6;
    private static final int MAX_CONDITIONS = 50;
    private static final int MAX_FILTER_DEPTH = 4;
    private static final int MAX_IN_VALUES = 1000;
    private static final int MAX_OFFSET = 1_000_000;
    private static final int DEFAULT_PAGE_SIZE = 50;
    private static final int EXPORT_TIMEOUT_SECONDS = 300;
    private static final Set<String> AGGREGATIONS = Set.of("sum", "avg", "min", "max", "countDistinct");

    private final Clock clock;
    private final int maxPageSize;

    public QueryBuilder(Clock reportingClock, @Value("${app.reporting.query.maxPageSize}") int maxPageSize) {
        this.clock = reportingClock;
        this.maxPageSize = maxPageSize;
    }

    /** On-screen query: one page of at most {@code maxPageSize} rows. */
    public QueryPlan build(QueryRequest req, Dataset ds) {
        return build(req, ds, null);
    }

    /** Download: the same definition, all matching rows up to {@code maxRows}, from the first row. */
    public QueryPlan buildExport(QueryRequest req, Dataset ds, int maxRows) {
        return build(req, ds, maxRows);
    }

    private QueryPlan build(QueryRequest req, Dataset ds, Integer exportRows) {
        List<String> columns = req.columns() == null ? List.of() : req.columns();
        List<MeasureSpec> measures = req.measures() == null ? List.of() : req.measures();
        if (columns.isEmpty() && measures.isEmpty()) {
            throw new InvalidQueryException("Choose at least one column or measure");
        }
        if (columns.size() > MAX_COLUMNS) {
            throw new InvalidQueryException("At most " + MAX_COLUMNS + " columns");
        }
        if (new LinkedHashSet<>(columns).size() != columns.size()) {
            throw new InvalidQueryException("A column is listed twice");
        }

        boolean aggregate = !measures.isEmpty();
        if (aggregate && columns.size() > MAX_GROUP_BY) {
            throw new InvalidQueryException("At most " + MAX_GROUP_BY + " group-by columns");
        }

        List<OutputColumn> out = new ArrayList<>();
        List<String> selectExprs = new ArrayList<>();
        List<String> dimensionExprs = new ArrayList<>();
        for (String name : columns) {
            Field f = dimension(ds, name);
            out.add(new OutputColumn(f.name(), f.label(), f.type().json(), "dimension"));
            selectExprs.add(f.expression() == null ? ident(f.name()) : f.expression() + " AS " + ident(f.name()));
            dimensionExprs.add(colExpr(f));
        }

        List<String> measureExprs = new ArrayList<>();
        for (MeasureSpec m : measures) {
            Field f = ds.field(m.field()).orElseThrow(() -> new InvalidQueryException("Unknown field: " + m.field()));
            String key;
            String expr;
            String label;
            String type;
            if (f.isMeasure()) {
                key = f.name();
                expr = f.expression();
                label = f.label();
                type = f.type().json();
            } else {
                String agg = m.agg();
                if (agg == null || !AGGREGATIONS.contains(agg) || !f.allowsAggregation(agg)) {
                    throw new InvalidQueryException("Aggregation '" + agg + "' is not allowed on " + f.label());
                }
                key = agg + "_" + f.name();
                expr = aggregateExpr(agg, f);
                label = aggLabel(agg) + " " + f.label();
                type = "countDistinct".equals(agg) || f.type() == FieldType.BOOLEAN ? "number" : f.type().json();
            }
            if (out.stream().anyMatch(c -> c.key().equals(key))) {
                throw new InvalidQueryException("Measure listed twice: " + label);
            }
            out.add(new OutputColumn(key, label, type, "measure"));
            measureExprs.add(expr + " AS " + ident(key));
        }
        selectExprs.addAll(measureExprs);

        Map<String, Object> params = new LinkedHashMap<>();
        String where = "is_deleted = 0";
        if (req.filter() != null) {
            int[] counter = {0};
            where += " AND (" + filterSql(req.filter(), ds, params, counter, 1) + ")";
        }

        String from = " FROM " + ident(ds.table()) + " FINAL WHERE " + where;
        String orderBy = orderBy(req.sort(), ds, out, aggregate);
        int pageSize;
        int offset;
        if (exportRows != null) {
            pageSize = exportRows;
            offset = 0;
        } else {
            pageSize = req.pageSize() == null ? DEFAULT_PAGE_SIZE : req.pageSize();
            offset = req.offset() == null ? 0 : req.offset();
            if (pageSize < 1 || pageSize > maxPageSize) {
                throw new InvalidQueryException("Page size must be between 1 and " + maxPageSize);
            }
            if (offset < 0 || offset > MAX_OFFSET) {
                throw new InvalidQueryException("Offset must be between 0 and " + MAX_OFFSET);
            }
        }
        params.put("limit", pageSize);
        params.put("offset", offset);

        String groupBy = aggregate && !dimensionExprs.isEmpty() ? " GROUP BY " + String.join(", ", dimensionExprs) : "";
        String dataSql = "SELECT " + String.join(", ", selectExprs) + from + groupBy + orderBy
                + " LIMIT :limit OFFSET :offset";
        if (exportRows != null) {
            // downloads need more than the interactive profile allows; values come from code, never from the request
            dataSql += " SETTINGS max_result_rows = " + (exportRows + 1) + ", max_execution_time = " + EXPORT_TIMEOUT_SECONDS;
        }
        String countSql = aggregate
                ? (groupBy.isEmpty() ? "SELECT 1" : "SELECT count() FROM (SELECT 1" + from + groupBy + ")")
                : "SELECT count()" + from;
        String totalsSql = aggregate ? "SELECT " + String.join(", ", measureExprs) + from : null;

        return new QueryPlan(aggregate ? "aggregate" : "detail", out, dataSql, countSql, totalsSql, params, pageSize, offset);
    }

    /** Top values of a field for filter drop-downs, optionally matching a typed prefix/fragment. */
    public QueryPlan suggestions(Dataset ds, String fieldName, String q, int limit) {
        Field f = dimension(ds, fieldName);
        if (!f.suggest()) {
            throw new InvalidQueryException("No value suggestions for " + f.label());
        }
        Map<String, Object> params = new LinkedHashMap<>();
        String where = "is_deleted = 0";
        if (q != null && !q.isBlank()) {
            where += " AND lower(" + ident(f.name()) + ") LIKE :q";
            params.put("q", "%" + escapeLike(q.trim().toLowerCase(Locale.ROOT)) + "%");
        }
        params.put("limit", limit);
        String sql = "SELECT " + ident(f.name()) + " AS v, count() AS n FROM " + ident(ds.table()) + " FINAL WHERE " + where
                + " GROUP BY v ORDER BY n DESC, v LIMIT :limit";
        return new QueryPlan("suggest", List.of(new OutputColumn("v", f.label(), f.type().json(), "dimension")),
                sql, null, null, params, limit, 0);
    }

    // ---------------------------------------------------------------- helpers

    private static Field dimension(Dataset ds, String name) {
        Field f = ds.field(name).orElseThrow(() -> new InvalidQueryException("Unknown field: " + name));
        if (f.isMeasure()) {
            throw new InvalidQueryException(f.label() + " is a measure, not a column");
        }
        return f;
    }

    private static String aggregateExpr(String agg, Field f) {
        String col = ident(f.name());
        int scale = f.scale() == null ? 2 : f.scale();
        return switch (agg) {
            case "sum" -> "sum(" + col + ")";
            case "avg" -> "round(avg(" + col + "), " + scale + ")";
            case "min" -> "min(" + col + ")";
            case "max" -> "max(" + col + ")";
            case "countDistinct" -> "uniqExact(" + col + ")";
            default -> throw new InvalidQueryException("Unknown aggregation " + agg);
        };
    }

    private static String aggLabel(String agg) {
        return switch (agg) {
            case "sum" -> "Total";
            case "avg" -> "Average";
            case "min" -> "Lowest";
            case "max" -> "Highest";
            default -> "Distinct";
        };
    }

    private String orderBy(List<SortSpec> sort, Dataset ds, List<OutputColumn> out, boolean aggregate) {
        List<String> parts = new ArrayList<>();
        if (sort != null && !sort.isEmpty()) {
            for (SortSpec s : sort) {
                boolean known = out.stream().anyMatch(c -> c.key().equals(s.field()))
                        || (!aggregate && ds.field(s.field()).filter(f -> !f.isMeasure()).isPresent());
                if (!known) {
                    throw new InvalidQueryException("Cannot sort by " + s.field());
                }
                parts.add(sortExpr(s.field(), ds) + direction(s.dir()));
            }
        } else if (aggregate) {
            out.stream().filter(c -> "measure".equals(c.role())).findFirst()
                    .ifPresent(c -> parts.add(ident(c.key()) + " DESC"));
        } else if (ds.defaultSort() != null) {
            ds.defaultSort().forEach(s -> parts.add(sortExpr(s.field(), ds) + direction(s.dir())));
        }
        return parts.isEmpty() ? "" : " ORDER BY " + String.join(", ", parts);
    }

    private static String direction(String dir) {
        if (dir == null || dir.equalsIgnoreCase("asc")) {
            return " ASC";
        }
        if (dir.equalsIgnoreCase("desc")) {
            return " DESC";
        }
        throw new InvalidQueryException("Sort direction must be asc or desc");
    }

    private String filterSql(FilterNode node, Dataset ds, Map<String, Object> params, int[] counter, int depth) {
        if (depth > MAX_FILTER_DEPTH) {
            throw new InvalidQueryException("Filters are nested too deeply");
        }
        boolean isAnd = node.and() != null && !node.and().isEmpty();
        boolean isOr = node.or() != null && !node.or().isEmpty();
        if (isAnd || isOr) {
            if (node.field() != null || (isAnd && isOr)) {
                throw new InvalidQueryException("A filter group must contain only 'and' or only 'or'");
            }
            List<String> parts = new ArrayList<>();
            for (FilterNode child : isAnd ? node.and() : node.or()) {
                parts.add("(" + filterSql(child, ds, params, counter, depth + 1) + ")");
            }
            return String.join(isAnd ? " AND " : " OR ", parts);
        }
        if (++counter[0] > MAX_CONDITIONS) {
            throw new InvalidQueryException("At most " + MAX_CONDITIONS + " filter conditions");
        }
        Field f = dimension(ds, node.field());
        String op = node.op();
        if (op == null || !f.type().allows(op)) {
            throw new InvalidQueryException("Operator '" + op + "' is not allowed on " + f.label());
        }
        String col = colExpr(f);
        String p = "p" + counter[0];
        Object v = node.value();
        switch (op) {
            case "eq", "neq", "gt", "gte", "lt", "lte" -> {
                params.put(p, scalar(f, v));
                return col + " " + comparator(op) + " :" + p;
            }
            case "in", "notIn" -> {
                List<Object> values = list(f, v);
                if (values.isEmpty() || values.size() > MAX_IN_VALUES) {
                    throw new InvalidQueryException("'" + op + "' needs 1 to " + MAX_IN_VALUES + " values");
                }
                params.put(p, values);
                return col + ("in".equals(op) ? " IN (:" : " NOT IN (:") + p + ")";
            }
            case "between" -> {
                List<Object> range = list(f, v);
                if (range.size() != 2) {
                    throw new InvalidQueryException("'between' needs exactly two values");
                }
                params.put(p + "a", range.get(0));
                params.put(p + "b", range.get(1));
                return col + " BETWEEN :" + p + "a AND :" + p + "b";
            }
            case "contains", "startsWith" -> {
                String text = text(v).toLowerCase(Locale.ROOT);
                if (text.isEmpty()) {
                    throw new InvalidQueryException("Enter text to search for in " + f.label());
                }
                params.put(p, ("contains".equals(op) ? "%" : "") + escapeLike(text) + "%");
                return "lower(" + col + ") LIKE :" + p;
            }
            case "relative" -> {
                LocalDate[] range = relativeRange(text(v));
                params.put(p + "a", range[0]);
                params.put(p + "b", range[1]);
                return col + " BETWEEN :" + p + "a AND :" + p + "b";
            }
            case "isTrue" -> {
                return col + " = 1";
            }
            case "isFalse" -> {
                return col + " = 0";
            }
            default -> throw new InvalidQueryException("Unknown operator " + op);
        }
    }

    private static String comparator(String op) {
        return switch (op) {
            case "eq" -> "=";
            case "neq" -> "!=";
            case "gt" -> ">";
            case "gte" -> ">=";
            case "lt" -> "<";
            default -> "<=";
        };
    }

    private static Object scalar(Field f, Object v) {
        if (v == null || v instanceof List<?> || v instanceof Map<?, ?>) {
            throw new InvalidQueryException("Enter a single value for " + f.label());
        }
        return switch (f.type()) {
            case STRING -> text(v);
            case NUMBER, MONEY -> number(f, v);
            case DATE -> date(f, v);
            case BOOLEAN -> throw new InvalidQueryException("Use isTrue/isFalse for " + f.label());
        };
    }

    private static List<Object> list(Field f, Object v) {
        if (!(v instanceof List<?> raw)) {
            throw new InvalidQueryException("Enter a list of values for " + f.label());
        }
        List<Object> out = new ArrayList<>();
        for (Object item : raw) {
            out.add(scalar(f, item));
        }
        return out;
    }

    private static String text(Object v) {
        if (!(v instanceof String s)) {
            throw new InvalidQueryException("Expected text but got " + (v == null ? "nothing" : v));
        }
        if (s.length() > 200) {
            throw new InvalidQueryException("Filter text is too long");
        }
        return s.trim();
    }

    private static BigDecimal number(Field f, Object v) {
        try {
            return v instanceof Number n ? new BigDecimal(n.toString()) : new BigDecimal(text(v));
        } catch (NumberFormatException e) {
            throw new InvalidQueryException("Enter a valid number for " + f.label());
        }
    }

    private static LocalDate date(Field f, Object v) {
        try {
            return LocalDate.parse(text(v));
        } catch (DateTimeParseException e) {
            throw new InvalidQueryException("Enter a date as YYYY-MM-DD for " + f.label());
        }
    }

    /** Inclusive [from, to] dates for a relative period, in the application time zone. */
    LocalDate[] relativeRange(String period) {
        LocalDate today = LocalDate.now(clock);
        return switch (period) {
            case "TODAY" -> new LocalDate[] {today, today};
            case "YESTERDAY" -> new LocalDate[] {today.minusDays(1), today.minusDays(1)};
            case "LAST_7_DAYS" -> new LocalDate[] {today.minusDays(6), today};
            case "LAST_30_DAYS" -> new LocalDate[] {today.minusDays(29), today};
            case "THIS_MONTH" -> new LocalDate[] {today.withDayOfMonth(1), today};
            case "LAST_MONTH" -> {
                LocalDate first = today.withDayOfMonth(1).minusMonths(1);
                yield new LocalDate[] {first, first.withDayOfMonth(first.lengthOfMonth())};
            }
            case "THIS_YEAR" -> new LocalDate[] {today.withDayOfYear(1), today};
            case "LAST_YEAR" -> {
                LocalDate first = today.withDayOfYear(1).minusYears(1);
                yield new LocalDate[] {first, first.withDayOfYear(first.lengthOfYear())};
            }
            default -> throw new InvalidQueryException("Unknown relative period " + period);
        };
    }

    /** LIKE wildcards typed by users match literally. */
    static String escapeLike(String s) {
        return s.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_");
    }

    /** SQL for a dimension: its catalogue expression (e.g. toStartOfMonth(...)) or the plain column. */
    private static String colExpr(Field f) {
        return f.expression() != null ? f.expression() : ident(f.name());
    }

    /** Sort keys: dataset fields by their expression, measure outputs by their alias. */
    private static String sortExpr(String key, Dataset ds) {
        return ds.field(key).filter(f -> !f.isMeasure()).map(QueryBuilder::colExpr).orElse(ident(key));
    }

    /** Identifiers come only from the validated catalogue; backticks guard against keyword clashes. */
    private static String ident(String name) {
        return "`" + name + "`";
    }
}
