package com.hospital.patientreg.reporting.query;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

/**
 * A report definition sent by the UI (never SQL). Without measures it is a detail list of
 * {@code columns}; with measures, {@code columns} are the group-by dimensions.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record QueryRequest(
        String dataset,
        List<String> columns,
        List<MeasureSpec> measures,
        FilterNode filter,
        List<SortSpec> sort,
        Integer pageSize,
        Integer offset) {

    /** {@code agg} is required for dimension fields (sum, avg, min, max, countDistinct); measures have a fixed one. */
    public record MeasureSpec(String field, String agg) {
    }

    public record SortSpec(String field, String dir) {
    }
}
