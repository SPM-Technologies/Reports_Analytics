package com.hospital.patientreg.reporting.query;

import java.time.LocalDateTime;
import java.util.List;

/** What the API returns for one Run: column metadata, one page of rows, totals and freshness. */
public record QueryResult(
        String dataset,
        String mode,
        List<QueryPlan.OutputColumn> columns,
        List<List<Object>> rows,
        List<Object> totals,
        long totalRows,
        int pageSize,
        int offset,
        LocalDateTime dataAsOf,
        long queryMs) {
}
