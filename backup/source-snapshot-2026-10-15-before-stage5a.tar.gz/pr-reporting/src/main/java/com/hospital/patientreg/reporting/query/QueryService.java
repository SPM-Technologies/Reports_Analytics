package com.hospital.patientreg.reporting.query;

import com.hospital.patientreg.reporting.semantic.Dataset;
import com.hospital.patientreg.reporting.semantic.DatasetCatalog;
import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

/** Runs report definitions against the analytics store (never the live database). */
@Service
public class QueryService {

    static final ZoneId IST = ZoneId.of("Asia/Kolkata");

    private final DatasetCatalog catalog;
    private final QueryBuilder builder;
    private final NamedParameterJdbcTemplate analytics;

    public QueryService(DatasetCatalog catalog, QueryBuilder builder,
                        @Qualifier("analyticsJdbc") NamedParameterJdbcTemplate analytics) {
        this.catalog = catalog;
        this.builder = builder;
        this.analytics = analytics;
    }

    public Dataset dataset(String id) {
        return catalog.find(id).orElseThrow(() -> new InvalidQueryException("Unknown dataset: " + id));
    }

    public QueryResult run(QueryRequest request) {
        long start = System.nanoTime();
        Dataset ds = dataset(request.dataset());
        QueryPlan plan = builder.build(request, ds);
        int width = plan.columns().size();

        List<List<Object>> rows = analytics.query(plan.dataSql(), plan.params(), (rs, i) -> row(rs, width));
        Long total = analytics.queryForObject(plan.countSql(), plan.params(), Long.class);
        List<Object> totals = plan.totalsSql() == null ? null
                : analytics.queryForObject(plan.totalsSql(), plan.params(), (rs, i) -> row(rs, rs.getMetaData().getColumnCount()));
        LocalDateTime asOf = dataAsOf(ds);

        long ms = (System.nanoTime() - start) / 1_000_000;
        return new QueryResult(ds.id(), plan.mode(), plan.columns(), rows, totals, total == null ? 0 : total,
                plan.pageSize(), plan.offset(), asOf, ms);
    }

    public List<Map<String, Object>> suggestions(String datasetId, String field, String q) {
        Dataset ds = dataset(datasetId);
        QueryPlan plan = builder.suggestions(ds, field, q, 50);
        return analytics.query(plan.dataSql(), plan.params(),
                (rs, i) -> Map.of("value", normalise(rs.getObject("v")), "count", rs.getLong("n")));
    }

    /**
     * How current the analytics copy is. With real-time sync (Debezium) a heartbeat arrives every few
     * seconds even when nobody registers, so its time is used; otherwise the commit time of the newest
     * change that has reached the analytics store.
     */
    public LocalDateTime dataAsOf(Dataset ds) {
        LocalDateTime newestChange = asTime(analytics.getJdbcTemplate().queryForObject(
                "SELECT max(`" + ds.freshnessColumn() + "`) FROM `" + ds.table() + "`", (rs, i) -> rs.getObject(1)));
        // generated or imported rows can carry future timestamps; data cannot be newer than now
        LocalDateTime now = LocalDateTime.now(IST);
        if (newestChange != null && newestChange.isAfter(now)) {
            newestChange = now;
        }
        LocalDateTime heartbeat = null;
        try {
            heartbeat = asTime(analytics.getJdbcTemplate().queryForObject(
                    "SELECT max(ts) FROM pipeline_heartbeat", (rs, i) -> rs.getObject(1)));
        } catch (DataAccessException noRealtimePipeline) {
            // table exists only when real-time sync is set up (docker compose --profile cdc)
        }
        if (heartbeat == null || heartbeat.getYear() < 2000) {
            return newestChange;
        }
        return newestChange == null || heartbeat.isAfter(newestChange) ? heartbeat : newestChange;
    }

    private static LocalDateTime asTime(Object v) {
        return normalise(v) instanceof LocalDateTime t ? t : null;
    }

    private static List<Object> row(ResultSet rs, int width) throws SQLException {
        List<Object> row = new ArrayList<>(width);
        for (int c = 1; c <= width; c++) {
            row.add(normalise(rs.getObject(c)));
        }
        return row;
    }

    /** JDBC values to JSON-friendly Java types (dates as ISO, unsigned ints as numbers, times in IST). */
    public static Object normalise(Object v) {
        if (v instanceof java.sql.Date d) {
            return d.toLocalDate();
        }
        if (v instanceof Timestamp t) {
            return t.toLocalDateTime();
        }
        if (v instanceof OffsetDateTime o) {
            return o.atZoneSameInstant(IST).toLocalDateTime();
        }
        if (v instanceof ZonedDateTime z) {
            return z.withZoneSameInstant(IST).toLocalDateTime();
        }
        if (v instanceof BigInteger b && b.bitLength() < 63) {
            return b.longValue();
        }
        // ClickHouse returns nan for an average over zero rows: show it as empty, not as the text "NaN"
        if ((v instanceof Double d && (d.isNaN() || d.isInfinite())) || (v instanceof Float f && (f.isNaN() || f.isInfinite()))) {
            return null;
        }
        return v;
    }
}
