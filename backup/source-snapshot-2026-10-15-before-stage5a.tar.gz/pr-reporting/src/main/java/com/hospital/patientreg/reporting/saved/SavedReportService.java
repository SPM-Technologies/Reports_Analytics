package com.hospital.patientreg.reporting.saved;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hospital.patientreg.reporting.query.InvalidQueryException;
import com.hospital.patientreg.reporting.query.QueryBuilder;
import com.hospital.patientreg.reporting.query.QueryRequest;
import com.hospital.patientreg.reporting.query.QueryService;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

/**
 * Saved reports. Every definition is validated with the same query builder used for Run, so a
 * stored report can always be opened and run. Until login exists (stage 5) all saved reports are
 * shared by everyone; ownership and sharing come with real user identity.
 */
@Service
public class SavedReportService {

    private static final int MAX_DEFINITION_CHARS = 50_000;

    private final SavedReportRepository repository;
    private final QueryService queryService;
    private final QueryBuilder builder;
    private final ObjectMapper json;

    public SavedReportService(SavedReportRepository repository, QueryService queryService, QueryBuilder builder,
                              ObjectMapper reportingObjectMapper) {
        this.repository = repository;
        this.queryService = queryService;
        this.builder = builder;
        this.json = reportingObjectMapper;
    }

    /** Report details sent by the UI when saving. */
    public record SaveRequest(String name, String description, JsonNode definition) {
    }

    public List<SavedReport> list() {
        return repository.list();
    }

    public SavedReport get(long id) {
        return repository.find(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Report not found"));
    }

    public SavedReport create(SaveRequest request) {
        String definition = validated(request);
        long id = repository.insert(request.name().trim(), description(request), definition);
        return get(id);
    }

    public SavedReport update(long id, SaveRequest request) {
        SavedReport existing = get(id);
        if (existing.template()) {
            throw new InvalidQueryException("Built-in templates cannot be changed; use Save as to keep your own copy.");
        }
        String definition = validated(request);
        repository.update(id, request.name().trim(), description(request), definition);
        return get(id);
    }

    public void delete(long id) {
        SavedReport existing = get(id);
        if (existing.template()) {
            throw new InvalidQueryException("Built-in templates cannot be deleted.");
        }
        repository.delete(id);
    }

    private String validated(SaveRequest request) {
        if (request == null || request.name() == null || request.name().isBlank()) {
            throw new InvalidQueryException("Enter a name for the report");
        }
        if (request.name().trim().length() > 120) {
            throw new InvalidQueryException("The name can have at most 120 characters");
        }
        if (request.description() != null && request.description().length() > 400) {
            throw new InvalidQueryException("The description can have at most 400 characters");
        }
        JsonNode def = request.definition();
        if (def == null || !def.isObject() || !def.has("query")) {
            throw new InvalidQueryException("The report definition is missing");
        }
        try {
            QueryRequest query = json.treeToValue(def.get("query"), QueryRequest.class);
            builder.build(query, queryService.dataset(query.dataset()));   // same validation as Run
            String text = json.writeValueAsString(def);
            if (text.length() > MAX_DEFINITION_CHARS) {
                throw new InvalidQueryException("The report definition is too large");
            }
            return text;
        } catch (JsonProcessingException e) {
            throw new InvalidQueryException("The report definition is not valid");
        }
    }

    private static String description(SaveRequest request) {
        return request.description() == null || request.description().isBlank() ? null : request.description().trim();
    }
}
