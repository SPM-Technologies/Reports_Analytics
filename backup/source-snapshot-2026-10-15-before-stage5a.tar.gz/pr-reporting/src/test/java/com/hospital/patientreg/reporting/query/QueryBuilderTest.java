package com.hospital.patientreg.reporting.query;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.hospital.patientreg.reporting.query.QueryRequest.MeasureSpec;
import com.hospital.patientreg.reporting.query.QueryRequest.SortSpec;
import com.hospital.patientreg.reporting.semantic.Dataset;
import com.hospital.patientreg.reporting.semantic.DatasetCatalog;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class QueryBuilderTest {

    private static Dataset patients;
    /** Fixed "now": 15 Oct 2026, 10:00 IST. */
    private final QueryBuilder builder = new QueryBuilder(
            Clock.fixed(Instant.parse("2026-10-15T04:30:00Z"), ZoneId.of("Asia/Kolkata")), 500);

    @BeforeAll
    static void loadCatalogue() throws Exception {
        patients = new DatasetCatalog(JsonMapper.builder().addModule(new JavaTimeModule()).build())
                .find("patients").orElseThrow();
    }

    private static QueryRequest detail(List<String> columns, FilterNode filter) {
        return new QueryRequest("patients", columns, null, filter, null, null, null);
    }

    @Test
    void detailListReadsLatestVersionsWithDefaultOrderAndPaging() {
        QueryPlan plan = builder.build(detail(List.of("registration_no", "patient_name", "gender"), null), patients);
        assertThat(plan.mode()).isEqualTo("detail");
        assertThat(plan.dataSql())
                .startsWith("SELECT `registration_no`, `patient_name`, `gender` FROM `patient_report` FINAL WHERE is_deleted = 0")
                .contains("ORDER BY `registration_date` DESC, `patient_id` DESC")
                .endsWith("LIMIT :limit OFFSET :offset");
        assertThat(plan.countSql()).isEqualTo("SELECT count() FROM `patient_report` FINAL WHERE is_deleted = 0");
        assertThat(plan.totalsSql()).isNull();
        assertThat(plan.params()).containsEntry("limit", 50).containsEntry("offset", 0);
    }

    @Test
    void aggregateGroupsAndComputesTotals() {
        QueryRequest req = new QueryRequest("patients", List.of("gender"),
                List.of(new MeasureSpec("patients", null), new MeasureSpec("registration_fee", "sum"),
                        new MeasureSpec("age_years", "avg")),
                null, null, null, null);
        QueryPlan plan = builder.build(req, patients);
        assertThat(plan.mode()).isEqualTo("aggregate");
        assertThat(plan.dataSql()).contains("count() AS `patients`", "sum(`registration_fee`) AS `sum_registration_fee`",
                "round(avg(`age_years`), 1) AS `avg_age_years`", "GROUP BY `gender`", "ORDER BY `patients` DESC");
        assertThat(plan.countSql()).startsWith("SELECT count() FROM (SELECT 1 FROM `patient_report` FINAL");
        assertThat(plan.totalsSql()).doesNotContain("GROUP BY").contains("count() AS `patients`");
        assertThat(plan.columns()).extracting("key").containsExactly("gender", "patients", "sum_registration_fee", "avg_age_years");
    }

    @Test
    void userValuesAreBoundNeverWrittenIntoSql() {
        String evil = "x'; DROP TABLE patient_report; --";
        QueryPlan plan = builder.build(detail(List.of("patient_name"),
                FilterNode.and(FilterNode.condition("city", "eq", evil),
                        FilterNode.condition("state", "in", List.of("Goa", evil)))), patients);
        assertThat(plan.dataSql()).doesNotContain("DROP").contains("`city` = :p1", "`state` IN (:p2)");
        assertThat(plan.params()).containsEntry("p1", evil);
    }

    @Test
    void onlyCatalogueFieldsOperatorsAndAggregationsAreAccepted() {
        assertThatThrownBy(() -> builder.build(detail(List.of("aadhaar"), null), patients))
                .isInstanceOf(InvalidQueryException.class).hasMessageContaining("Unknown field");
        assertThatThrownBy(() -> builder.build(detail(List.of("gender; DROP TABLE x"), null), patients))
                .isInstanceOf(InvalidQueryException.class);
        assertThatThrownBy(() -> builder.build(detail(List.of("gender"),
                FilterNode.condition("registration_date", "contains", "2026")), patients))
                .hasMessageContaining("not allowed");
        assertThatThrownBy(() -> builder.build(new QueryRequest("patients", List.of("city"),
                List.of(new MeasureSpec("gender", "sum")), null, null, null, null), patients))
                .hasMessageContaining("not allowed");
        assertThatThrownBy(() -> builder.build(detail(List.of("patients"), null), patients))
                .hasMessageContaining("is a measure");
        assertThatThrownBy(() -> builder.build(new QueryRequest("patients", List.of("gender"), null, null,
                List.of(new SortSpec("gender; DROP", "asc")), null, null), patients))
                .hasMessageContaining("Cannot sort");
    }

    @Test
    void containsIsCaseInsensitiveAndEscapesWildcards() {
        QueryPlan plan = builder.build(detail(List.of("patient_name"),
                FilterNode.condition("patient_name", "contains", "Rao_50%")), patients);
        assertThat(plan.dataSql()).contains("lower(`patient_name`) LIKE :p1");
        assertThat(plan.params()).containsEntry("p1", "%rao\\_50\\%%");
    }

    @Test
    void relativeDatesAreComputedInIst() {
        QueryPlan plan = builder.build(detail(List.of("registration_no"),
                FilterNode.condition("registration_date", "relative", "LAST_30_DAYS")), patients);
        assertThat(plan.params()).containsEntry("p1a", LocalDate.of(2026, 9, 16)).containsEntry("p1b", LocalDate.of(2026, 10, 15));
        assertThat(builder.relativeRange("LAST_MONTH")).containsExactly(LocalDate.of(2026, 9, 1), LocalDate.of(2026, 9, 30));
    }

    @Test
    void typedValuesAreValidated() {
        assertThatThrownBy(() -> builder.build(detail(List.of("gender"),
                FilterNode.condition("registration_date", "gte", "15-10-2026")), patients))
                .hasMessageContaining("YYYY-MM-DD");
        assertThatThrownBy(() -> builder.build(detail(List.of("gender"),
                FilterNode.condition("age_years", "between", List.of(10))), patients))
                .hasMessageContaining("exactly two");
        QueryPlan plan = builder.build(detail(List.of("gender"), FilterNode.condition("is_insured", "isTrue", null)), patients);
        assertThat(plan.dataSql()).contains("`is_insured` = 1");
    }

    @Test
    void limitsAreEnforced() {
        assertThatThrownBy(() -> builder.build(new QueryRequest("patients", List.of("gender"), null, null, null, 5000, null), patients))
                .hasMessageContaining("Page size");
        FilterNode deep = FilterNode.condition("gender", "eq", "Male");
        for (int i = 0; i < 5; i++) {
            deep = FilterNode.and(deep);
        }
        FilterNode tooDeep = deep;
        assertThatThrownBy(() -> builder.build(detail(List.of("gender"), tooDeep), patients))
                .hasMessageContaining("nested too deeply");
    }

    @Test
    void suggestionsOnlyForSuggestFields() {
        QueryPlan plan = builder.suggestions(patients, "city", "pu", 50);
        assertThat(plan.dataSql()).contains("lower(`city`) LIKE :q", "GROUP BY v ORDER BY n DESC");
        assertThatThrownBy(() -> builder.suggestions(patients, "patient_name", null, 50))
                .hasMessageContaining("No value suggestions");
    }
}
