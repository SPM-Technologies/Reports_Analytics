package com.hospital.patientreg.shared.export;

import java.util.function.Consumer;

/**
 * Everything an exporter needs: titles, column headers, relative column widths,
 * a row source (streamed so huge reports never sit fully in memory) and an optional totals row.
 */
public record ReportDefinition(
        String title,
        String subtitle,
        String[] headers,
        float[] widths,
        Consumer<Consumer<Object[]>> rows,
        Object[] totalRow) {
}
