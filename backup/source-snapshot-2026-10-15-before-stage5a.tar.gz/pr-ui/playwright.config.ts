import { defineConfig } from '@playwright/test';

// End-to-end tests of the deployed app (Tomcat must be running with the current WAR).
// Uses the installed Microsoft Edge, so no browser download is needed.  Run:  npm run e2e
export default defineConfig({
  testDir: './e2e',
  timeout: 60_000,
  expect: { timeout: 15_000 },
  fullyParallel: false,
  workers: 1,
  retries: 0,
  reporter: [['list']],
  use: {
    baseURL: process.env.APP_URL ?? 'http://localhost:8080/patient-registration/',
    channel: 'msedge',
    headless: true,
    viewport: { width: 1500, height: 950 },
    acceptDownloads: true,
    screenshot: 'only-on-failure',
  },
});
