// Shapes exchanged with the reporting API (/api/v1). Kept in step with pr-reporting by hand
// (OpenAPI-generated types are planned after the Spring upgrade).

export type FieldType = 'string' | 'number' | 'money' | 'date' | 'boolean';

export interface Field {
  name: string;
  label: string;
  type: FieldType;
  role: 'dimension' | 'measure';
  operators: string[];
  aggregations: string[];
  suggest: boolean;
}

export interface Dataset {
  id: string;
  label: string;
  description: string;
  fields: Field[];
}

export interface MeasureSpec {
  field: string;
  agg?: string;
}

export interface SortSpec {
  field: string;
  dir: 'asc' | 'desc';
}

export interface FilterCondition {
  field: string;
  op: string;
  value?: unknown;
}

export interface FilterNode {
  and?: FilterNode[];
  or?: FilterNode[];
  field?: string;
  op?: string;
  value?: unknown;
}

/** What the API runs: never SQL. */
export interface QueryRequest {
  dataset: string;
  columns: string[];
  measures?: MeasureSpec[];
  filter?: FilterNode;
  sort?: SortSpec[];
  pageSize?: number;
  offset?: number;
}

export interface OutputColumn {
  key: string;
  label: string;
  type: FieldType;
  role: 'dimension' | 'measure';
}

export interface QueryResult {
  dataset: string;
  mode: 'detail' | 'aggregate';
  columns: OutputColumn[];
  rows: unknown[][];
  totals: unknown[] | null;
  totalRows: number;
  pageSize: number;
  offset: number;
  dataAsOf: string | null;
  queryMs: number;
}

export type ViewMode = 'table' | 'chart';
export type ChartType = 'bar' | 'line' | 'pie';

export interface ViewSettings {
  mode: ViewMode;
  chart?: ChartType;
}

/** Stored with a saved report. */
export interface ReportDefinition {
  query: QueryRequest;
  view: ViewSettings;
}

export interface SavedReport {
  id: number;
  name: string;
  description?: string;
  template: boolean;
  updatedAt: string;
  definition?: ReportDefinition;
}
