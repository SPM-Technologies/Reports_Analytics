import type { Dataset, QueryRequest, QueryResult, ReportDefinition, SavedReport } from './types';

/**
 * Context path of the web application. Tomcat serves the UI at <context>/app/, so everything before
 * "/app" is the context; during `npm run dev` (served at /) the default deployment path is used.
 */
export const contextPath: string = (() => {
  const p = window.location.pathname;
  const i = p.indexOf('/app');
  return i >= 0 ? p.substring(0, i) : '/patient-registration';
})();

const API = `${contextPath}/api/v1`;

/** Error carrying the server's problem+json "detail" message, shown to the user as is. */
export class ApiError extends Error {}

async function failure(res: Response): Promise<never> {
  let message = `Request failed (${res.status})`;
  try {
    const body = await res.json();
    if (body && typeof body.detail === 'string') {
      message = body.detail;
    }
  } catch {
    // not JSON: keep the generic message
  }
  throw new ApiError(message);
}

async function call<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(API + path, {
    ...init,
    headers: { Accept: 'application/json', ...(init?.body ? { 'Content-Type': 'application/json' } : {}) },
    credentials: 'same-origin',
  });
  if (!res.ok) {
    return failure(res);
  }
  return (res.status === 204 ? undefined : await res.json()) as T;
}

export const api = {
  datasets: () => call<Dataset[]>('/datasets'),

  query: (request: QueryRequest) => call<QueryResult>('/query', { method: 'POST', body: JSON.stringify(request) }),

  suggestions: (dataset: string, field: string, q: string) =>
    call<{ value: unknown; count: number }[]>(
      `/datasets/${encodeURIComponent(dataset)}/fields/${encodeURIComponent(field)}/values?q=${encodeURIComponent(q)}`,
    ),

  reports: () => call<SavedReport[]>('/reports'),
  report: (id: number) => call<SavedReport>(`/reports/${id}`),
  createReport: (name: string, description: string, definition: ReportDefinition) =>
    call<SavedReport>('/reports', { method: 'POST', body: JSON.stringify({ name, description, definition }) }),
  updateReport: (id: number, name: string, description: string, definition: ReportDefinition) =>
    call<SavedReport>(`/reports/${id}`, { method: 'PUT', body: JSON.stringify({ name, description, definition }) }),
  deleteReport: (id: number) => call<void>(`/reports/${id}`, { method: 'DELETE' }),

  /** Downloads the report as a file; errors (e.g. too many rows for PDF) are thrown as ApiError. */
  async download(query: QueryRequest, format: 'xlsx' | 'pdf' | 'csv', title: string): Promise<void> {
    const res = await fetch(`${API}/query/export`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify({ query: { ...query, offset: undefined }, format, title }),
    });
    if (!res.ok) {
      return failure(res);
    }
    const disposition = res.headers.get('Content-Disposition') ?? '';
    const name = /filename="([^"]+)"/.exec(disposition)?.[1] ?? `report.${format}`;
    const url = URL.createObjectURL(await res.blob());
    const link = document.createElement('a');
    link.href = url;
    link.download = name;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 10_000);
  },
};
