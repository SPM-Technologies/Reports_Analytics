import type { Dataset, Field, FilterNode, MeasureSpec, QueryRequest, ReportDefinition, SortSpec, ViewSettings } from './types';

/** One editable filter row. Values are kept as typed text and converted when the query is built. */
export interface ConditionRow {
  id: number;
  field: string;
  op: string;
  text: string;      // eq/neq/contains/startsWith/gt..lte/relative; comma-separated list for in/notIn
  text2: string;     // second bound for "between"
}

/** Everything the builder edits. */
export interface BuilderState {
  dataset: string;
  columns: string[];
  measures: MeasureSpec[];
  match: 'and' | 'or';
  conditions: ConditionRow[];
  sort: SortSpec[];
  pageSize: number;
  view: ViewSettings;
}

let nextId = 1;
export const newConditionId = () => nextId++;

export const OPERATOR_LABELS: Record<string, string> = {
  eq: 'is',
  neq: 'is not',
  in: 'is any of',
  notIn: 'is none of',
  contains: 'contains',
  startsWith: 'starts with',
  gt: 'greater than',
  gte: 'at least',
  lt: 'less than',
  lte: 'at most',
  between: 'between',
  relative: 'in period',
  isTrue: 'is Yes',
  isFalse: 'is No',
};

/** Preferred operator order in the drop-down. */
const OPERATOR_ORDER = Object.keys(OPERATOR_LABELS);
export const sortedOperators = (ops: string[]) => [...ops].sort((a, b) => OPERATOR_ORDER.indexOf(a) - OPERATOR_ORDER.indexOf(b));

export const RELATIVE_PERIODS: [string, string][] = [
  ['TODAY', 'Today'],
  ['YESTERDAY', 'Yesterday'],
  ['LAST_7_DAYS', 'Last 7 days'],
  ['LAST_30_DAYS', 'Last 30 days'],
  ['THIS_MONTH', 'This month'],
  ['LAST_MONTH', 'Last month'],
  ['THIS_YEAR', 'This year'],
  ['LAST_YEAR', 'Last year'],
];

export const AGG_LABELS: Record<string, string> = {
  sum: 'Total',
  avg: 'Average',
  min: 'Lowest',
  max: 'Highest',
  countDistinct: 'Distinct',
};

/** Measure choices: fixed measures (e.g. Patients) and every allowed aggregation of a dimension. */
export function measureOptions(ds: Dataset): { key: string; spec: MeasureSpec; label: string }[] {
  const out: { key: string; spec: MeasureSpec; label: string }[] = [];
  for (const f of ds.fields) {
    if (f.role === 'measure') {
      out.push({ key: f.name, spec: { field: f.name }, label: f.label });
    } else {
      for (const agg of f.aggregations) {
        out.push({ key: `${agg}_${f.name}`, spec: { field: f.name, agg }, label: `${AGG_LABELS[agg] ?? agg} ${f.label}` });
      }
    }
  }
  return out;
}

export const measureKey = (m: MeasureSpec) => (m.agg ? `${m.agg}_${m.field}` : m.field);

export function emptyState(ds: Dataset): BuilderState {
  return {
    dataset: ds.id,
    columns: ['registration_no', 'registration_date', 'patient_name', 'gender', 'dept_name'].filter(n => ds.fields.some(f => f.name === n)),
    measures: [],
    match: 'and',
    conditions: [],
    sort: [],
    pageSize: 50,
    view: { mode: 'table' },
  };
}

export function defaultOperator(f: Field): string {
  if (f.type === 'date') return 'relative';
  if (f.type === 'boolean') return 'isTrue';
  if (f.type === 'string') return f.suggest ? 'in' : 'contains';
  return 'gte';
}

/** Converts typed text into the value the API expects for the operator; null if incomplete. */
function conditionValue(row: ConditionRow): unknown | null {
  const t = row.text.trim();
  switch (row.op) {
    case 'isTrue':
    case 'isFalse':
      return undefined;
    case 'in':
    case 'notIn': {
      const list = row.text.split(',').map(s => s.trim()).filter(Boolean);
      return list.length ? list : null;
    }
    case 'between':
      return t && row.text2.trim() ? [t, row.text2.trim()] : null;
    default:
      return t ? t : null;
  }
}

/** Builds the API request; incomplete filter rows are skipped (the UI marks them). */
export function toQuery(s: BuilderState, offset = 0): QueryRequest {
  const conditions: FilterNode[] = [];
  for (const row of s.conditions) {
    const value = conditionValue(row);
    if (value !== null) {
      conditions.push(value === undefined ? { field: row.field, op: row.op } : { field: row.field, op: row.op, value });
    }
  }
  return {
    dataset: s.dataset,
    columns: s.columns,
    measures: s.measures.length ? s.measures : undefined,
    filter: conditions.length ? { [s.match]: conditions } : undefined,
    sort: s.sort.length ? s.sort : undefined,
    pageSize: s.pageSize,
    offset,
  };
}

export const isIncomplete = (row: ConditionRow) => conditionValue(row) === null;

export function toDefinition(s: BuilderState): ReportDefinition {
  const query = toQuery(s);
  delete query.offset;
  return { query, view: s.view };
}

/** Opens a saved definition in the builder (flat AND/OR filter lists; nested groups are flattened to their first level). */
export function fromDefinition(def: ReportDefinition): BuilderState {
  const q = def.query;
  const group = q.filter?.and ? 'and' : 'or';
  const nodes = q.filter ? (q.filter.and ?? q.filter.or ?? [q.filter]) : [];
  const conditions: ConditionRow[] = nodes
    .filter(n => n.field && n.op)
    .map(n => {
      const v = n.value;
      const list = Array.isArray(v) ? v.map(String) : [];
      return {
        id: newConditionId(),
        field: n.field!,
        op: n.op!,
        text: n.op === 'between' ? (list[0] ?? '') : Array.isArray(v) ? list.join(', ') : v == null ? '' : String(v),
        text2: n.op === 'between' ? (list[1] ?? '') : '',
      };
    });
  return {
    dataset: q.dataset,
    columns: q.columns ?? [],
    measures: q.measures ?? [],
    match: group,
    conditions,
    sort: q.sort ?? [],
    pageSize: q.pageSize ?? 50,
    view: def.view ?? { mode: 'table' },
  };
}
