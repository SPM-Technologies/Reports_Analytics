import { type ReactNode, useCallback, useEffect, useRef, useState } from 'react';
import { ApiError, api, contextPath } from './api';
import { Builder } from './components/Builder';
import { ReportList } from './components/ReportList';
import { ResultsChart, chartable } from './components/ResultsChart';
import { ResultsTable } from './components/ResultsTable';
import { type BuilderState, emptyState, fromDefinition, toDefinition, toQuery } from './definition';
import { formatDateTime } from './format';
import type { ChartType, Dataset, QueryResult, SavedReport } from './types';

interface Current {
  id: number | null;
  name: string;
  template: boolean;
}

const message = (e: unknown) => (e instanceof ApiError ? e.message : 'Could not reach the server. Please try again.');

function hashReportId(): number | null {
  const m = /report=(\d+)/.exec(window.location.hash);
  return m ? Number(m[1]) : null;
}

export function App() {
  const [dataset, setDataset] = useState<Dataset | null>(null);
  const [reports, setReports] = useState<SavedReport[]>([]);
  const [state, setState] = useState<BuilderState | null>(null);
  const [current, setCurrent] = useState<Current>({ id: null, name: 'New report', template: false });
  const [result, setResult] = useState<QueryResult | null>(null);
  const [running, setRunning] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  // Responses can arrive out of order (fast paging, opening a report while another loads, clicking
  // "New report" during the initial load). Only the latest request of each kind may update the screen.
  const runSeq = useRef(0);
  const viewSeq = useRef(0);

  const run = useCallback(async (s: BuilderState, offset = 0) => {
    const seq = ++runSeq.current;
    setRunning(true);
    setError(null);
    try {
      const r = await api.query(toQuery(s, offset));
      if (seq === runSeq.current) setResult(r);
    } catch (e) {
      if (seq === runSeq.current) setError(message(e));
    } finally {
      if (seq === runSeq.current) setRunning(false);
    }
  }, []);

  const openReport = useCallback(async (id: number) => {
    const seq = ++viewSeq.current;
    try {
      const full = await api.report(id);
      if (seq !== viewSeq.current) return;   // the user moved on meanwhile
      const s = fromDefinition(full.definition!);
      setState(s);
      setCurrent({ id: full.id, name: full.name, template: full.template });
      window.history.replaceState(null, '', `#report=${full.id}`);
      setNotice(null);
      await run(s);
    } catch (e) {
      setError(message(e));
    }
  }, [run]);

  // Initial load: catalogue, report list, then the bookmarked report or the Patient Register template.
  useEffect(() => {
    (async () => {
      try {
        const [datasets, list] = await Promise.all([api.datasets(), api.reports()]);
        setDataset(datasets[0]);
        setReports(list);
        const bookmarked = hashReportId();
        const wanted = bookmarked !== null && list.some(r => r.id === bookmarked)
          ? bookmarked
          : list.find(r => r.template)?.id ?? null;
        if (wanted !== null) {
          await openReport(wanted);
        } else {
          setState(emptyState(datasets[0]));
        }
        if (bookmarked !== null && wanted !== bookmarked) {
          setNotice('The bookmarked report no longer exists; showing a template instead.');
        }
      } catch (e) {
        setError(message(e));
      }
    })();
  }, [openReport]);

  if (!dataset || !state) {
    return <Shell><p className="loading" role="status">{error ?? 'Loading reports...'}</p></Shell>;
  }

  const newReport = () => {
    viewSeq.current++;   // ignore a report still being opened ...
    runSeq.current++;    // ... and results of a query still running
    setRunning(false);
    const s = emptyState(dataset);
    setState(s);
    setCurrent({ id: null, name: 'New report', template: false });
    setResult(null);
    setNotice(null);
    window.history.replaceState(null, '', '#');
  };

  const refreshList = async () => setReports(await api.reports());

  const saveAs = async () => {
    const name = window.prompt('Name for this report:', current.template ? `${current.name} (copy)` : current.name);
    if (!name || !name.trim()) return;
    setBusy('save');
    try {
      const saved = await api.createReport(name.trim(), '', toDefinition(state));
      setCurrent({ id: saved.id, name: saved.name, template: false });
      window.history.replaceState(null, '', `#report=${saved.id}`);
      await refreshList();
      setNotice(`Saved as "${saved.name}".`);
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(null);
    }
  };

  const save = async () => {
    if (current.id === null || current.template) {
      await saveAs();
      return;
    }
    setBusy('save');
    try {
      await api.updateReport(current.id, current.name, '', toDefinition(state));
      await refreshList();
      setNotice(`Saved "${current.name}".`);
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(null);
    }
  };

  const remove = async () => {
    if (current.id === null || current.template || !window.confirm(`Delete the report "${current.name}"?`)) return;
    try {
      await api.deleteReport(current.id);
      await refreshList();
      newReport();
      setNotice('Report deleted.');
    } catch (e) {
      setError(message(e));
    }
  };

  const download = async (format: 'xlsx' | 'pdf' | 'csv') => {
    setBusy(format);
    setError(null);
    try {
      await api.download(toQuery(state), format, current.name);
    } catch (e) {
      setError(message(e));
    } finally {
      setBusy(null);
    }
  };

  // Header click: none -> ascending -> descending -> none (server-side sort, back to page 1).
  const toggleSort = (field: string) => {
    const existing = state.sort.find(s => s.field === field);
    const sort = !existing ? [{ field, dir: 'asc' as const }] : existing.dir === 'asc' ? [{ field, dir: 'desc' as const }] : [];
    const s = { ...state, sort };
    setState(s);
    run(s);
  };

  const pages = result ? Math.max(1, Math.ceil(result.totalRows / result.pageSize)) : 1;
  const page = result ? Math.floor(result.offset / result.pageSize) + 1 : 1;
  const canChart = result !== null && chartable(result);
  const showChart = state.view.mode === 'chart' && canChart;
  const setView = (patch: Partial<BuilderState['view']>) => setState({ ...state, view: { ...state.view, ...patch } });

  return (
    <Shell>
      <div className="layout">
        <ReportList reports={reports} currentId={current.id} onOpen={r => openReport(r.id)} onNew={newReport} />
        <Builder dataset={dataset} state={state} onChange={setState} onRun={() => run(state)} running={running} />

        <main className="results-panel" aria-busy={running}>
          <header className="results-head">
            <div>
              <h1>{current.name}{current.template && <span className="badge">Template</span>}</h1>
              {result && (
                <p className="meta" role="status">
                  {result.totalRows.toLocaleString('en-IN')} {result.mode === 'aggregate' ? 'groups' : 'rows'}
                  {' · '}{(result.queryMs / 1000).toFixed(2)} s
                  {' · '}Data as of {formatDateTime(result.dataAsOf)}
                </p>
              )}
            </div>
            <div className="actions">
              <button type="button" onClick={save} disabled={busy !== null}>{current.id !== null && !current.template ? 'Save' : 'Save as'}</button>
              {current.id !== null && !current.template && <button type="button" onClick={saveAs} disabled={busy !== null}>Save as</button>}
              {current.id !== null && !current.template && <button type="button" className="danger" onClick={remove}>Delete</button>}
              <span className="divider" />
              <button type="button" onClick={() => download('xlsx')} disabled={busy !== null || !result}>{busy === 'xlsx' ? 'Preparing...' : 'Excel'}</button>
              <button type="button" onClick={() => download('pdf')} disabled={busy !== null || !result}>{busy === 'pdf' ? 'Preparing...' : 'PDF'}</button>
              <button type="button" onClick={() => download('csv')} disabled={busy !== null || !result}>{busy === 'csv' ? 'Preparing...' : 'CSV'}</button>
            </div>
          </header>

          {error && <div className="alert error" role="alert">{error}</div>}
          {notice && !error && <div className="alert ok" role="status">{notice}</div>}

          {result && (
            <>
              <div className="view-bar">
                <div className="segmented" role="group" aria-label="View">
                  <button type="button" aria-pressed={!showChart} onClick={() => setView({ mode: 'table' })}>Table</button>
                  <button type="button" aria-pressed={showChart} disabled={!canChart}
                          title={canChart ? undefined : 'Add a measure and a group column to chart'}
                          onClick={() => setView({ mode: 'chart', chart: state.view.chart ?? 'bar' })}>Chart</button>
                </div>
                {showChart && (
                  <label>Chart type
                    <select value={state.view.chart ?? 'bar'} onChange={e => setView({ chart: e.target.value as ChartType })}>
                      <option value="bar">Bar</option>
                      <option value="line">Line</option>
                      <option value="pie">Pie</option>
                    </select>
                  </label>
                )}
              </div>
              {showChart ? <ResultsChart result={result} type={state.view.chart ?? 'bar'} />
                         : <ResultsTable result={result} sort={state.sort} onSort={toggleSort} />}
              {!showChart && pages > 1 && (
                <nav className="pager" aria-label="Pages">
                  <button type="button" disabled={page <= 1 || running} onClick={() => run(state, 0)}>« First</button>
                  <button type="button" disabled={page <= 1 || running} onClick={() => run(state, result.offset - result.pageSize)}>‹ Prev</button>
                  <span>Page {page.toLocaleString('en-IN')} of {pages.toLocaleString('en-IN')}</span>
                  <button type="button" disabled={page >= pages || running} onClick={() => run(state, result.offset + result.pageSize)}>Next ›</button>
                  <button type="button" disabled={page >= pages || running} onClick={() => run(state, (pages - 1) * result.pageSize)}>Last »</button>
                </nav>
              )}
            </>
          )}
          {!result && !error && <p className="hint big">Choose columns and filters, then press Run.</p>}
        </main>
      </div>
    </Shell>
  );
}

/** Top bar shared with the JSP screens' look, with links back to them. */
function Shell({ children }: { children: ReactNode }) {
  return (
    <>
      <header className="topbar">
        <div className="brand">✚ Patient Registration <span>Analytics</span></div>
        <nav aria-label="Application">
          <a href={`${contextPath}/`}>Dashboard</a>
          <a href={`${contextPath}/patient/new`}>New Registration</a>
          <a href={`${contextPath}/reports/register`}>Patient Register</a>
          <a href={`${contextPath}/reports/summary`}>Department Summary</a>
          <a href={`${contextPath}/app/`} className="active" aria-current="page">Analytics</a>
        </nav>
      </header>
      {children}
    </>
  );
}
