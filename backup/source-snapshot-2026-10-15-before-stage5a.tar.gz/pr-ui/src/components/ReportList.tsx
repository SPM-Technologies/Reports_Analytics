import type { SavedReport } from '../types';

interface Props {
  reports: SavedReport[];
  currentId: number | null;
  onOpen: (report: SavedReport) => void;
  onNew: () => void;
}

/** Built-in templates and saved reports. */
export function ReportList({ reports, currentId, onOpen, onNew }: Props) {
  const templates = reports.filter(r => r.template);
  const saved = reports.filter(r => !r.template);
  const item = (r: SavedReport) => (
    <li key={r.id}>
      <button type="button" className={`report-link${r.id === currentId ? ' current' : ''}`}
              aria-current={r.id === currentId ? 'true' : undefined} onClick={() => onOpen(r)} title={r.description}>
        {r.name}
      </button>
    </li>
  );
  return (
    <nav className="report-list" aria-label="Reports">
      <button type="button" className="primary block" onClick={onNew}>+ New report</button>
      <h2>Templates</h2>
      <ul>{templates.map(item)}</ul>
      <h2>Saved reports</h2>
      {saved.length === 0 ? <p className="hint">Nothing saved yet. Build a report and choose Save as.</p> : <ul>{saved.map(item)}</ul>}
    </nav>
  );
}
