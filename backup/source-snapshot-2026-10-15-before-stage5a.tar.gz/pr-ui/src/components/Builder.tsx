import { type BuilderState, defaultOperator, measureKey, measureOptions, newConditionId } from '../definition';
import type { Dataset } from '../types';
import { FilterRow } from './FilterRow';

interface Props {
  dataset: Dataset;
  state: BuilderState;
  onChange: (state: BuilderState) => void;
  onRun: () => void;
  running: boolean;
}

const MAX_GROUP_BY = 6;

/** Left panel: what to show (columns), how to summarise (measures), which rows (filters). */
export function Builder({ dataset, state, onChange, onRun, running }: Props) {
  const dims = dataset.fields.filter(f => f.role === 'dimension');
  const label = (name: string) => dataset.fields.find(f => f.name === name)?.label ?? name;
  const grouped = state.measures.length > 0;
  const options = measureOptions(dataset);
  const set = (patch: Partial<BuilderState>) => onChange({ ...state, ...patch });

  const move = (index: number, delta: number) => {
    const cols = [...state.columns];
    const target = index + delta;
    if (target < 0 || target >= cols.length) return;
    [cols[index], cols[target]] = [cols[target], cols[index]];
    set({ columns: cols });
  };

  return (
    <form className="builder" onSubmit={e => { e.preventDefault(); onRun(); }}>
      <section>
        <h2>{grouped ? 'Group by' : 'Columns'}</h2>
        {grouped && <p className="hint">With a summary, these columns become groups (up to {MAX_GROUP_BY}).</p>}
        <ol className="chosen">
          {state.columns.map((c, i) => (
            <li key={c}>
              <span>{label(c)}</span>
              <span className="row-actions">
                <button type="button" className="icon" aria-label={`Move ${label(c)} up`} onClick={() => move(i, -1)} disabled={i === 0}>↑</button>
                <button type="button" className="icon" aria-label={`Move ${label(c)} down`} onClick={() => move(i, 1)} disabled={i === state.columns.length - 1}>↓</button>
                <button type="button" className="icon" aria-label={`Remove ${label(c)}`} onClick={() => set({ columns: state.columns.filter(x => x !== c), sort: state.sort.filter(s => s.field !== c) })}>✕</button>
              </span>
            </li>
          ))}
        </ol>
        <label className="sr-only" htmlFor="add-column">Add column</label>
        <select id="add-column" value="" onChange={e => e.target.value && set({ columns: [...state.columns, e.target.value] })}>
          <option value="">+ Add column...</option>
          {dims.filter(f => !state.columns.includes(f.name)).map(f => <option key={f.name} value={f.name}>{f.label}</option>)}
        </select>
      </section>

      <section>
        <h2>Summarise</h2>
        {state.measures.length === 0 && <p className="hint">No summary: one row per patient. Add a measure to count or total by group.</p>}
        <ul className="chosen">
          {state.measures.map(m => {
            const opt = options.find(o => o.key === measureKey(m));
            return (
              <li key={measureKey(m)}>
                <span>{opt?.label ?? measureKey(m)}</span>
                <button type="button" className="icon" aria-label={`Remove ${opt?.label}`}
                        onClick={() => set({ measures: state.measures.filter(x => measureKey(x) !== measureKey(m)), sort: state.sort.filter(s => s.field !== measureKey(m)) })}>✕</button>
              </li>
            );
          })}
        </ul>
        <label className="sr-only" htmlFor="add-measure">Add measure</label>
        <select id="add-measure" value="" onChange={e => {
          const opt = options.find(o => o.key === e.target.value);
          if (opt) set({ measures: [...state.measures, opt.spec] });
        }}>
          <option value="">+ Add measure...</option>
          {options.filter(o => !state.measures.some(m => measureKey(m) === o.key)).map(o => <option key={o.key} value={o.key}>{o.label}</option>)}
        </select>
      </section>

      <section>
        <h2>Filters</h2>
        {state.conditions.length > 1 && (
          <div className="match" role="radiogroup" aria-label="Combine filters">
            <label><input type="radio" checked={state.match === 'and'} onChange={() => set({ match: 'and' })} /> Match all</label>
            <label><input type="radio" checked={state.match === 'or'} onChange={() => set({ match: 'or' })} /> Match any</label>
          </div>
        )}
        {state.conditions.map(row => (
          <FilterRow key={row.id} row={row} fields={dims} dataset={dataset.id}
                     onChange={r => set({ conditions: state.conditions.map(x => (x.id === r.id ? r : x)) })}
                     onRemove={() => set({ conditions: state.conditions.filter(x => x.id !== row.id) })} />
        ))}
        <button type="button" className="link" onClick={() => {
          const f = dims.find(d => d.name === 'registration_date') ?? dims[0];
          set({ conditions: [...state.conditions, { id: newConditionId(), field: f.name, op: defaultOperator(f), text: '', text2: '' }] });
        }}>+ Add filter</button>
      </section>

      <section className="run-row">
        <label>Rows per page
          <select value={state.pageSize} onChange={e => set({ pageSize: Number(e.target.value) })}>
            {[25, 50, 100, 250, 500].map(n => <option key={n} value={n}>{n}</option>)}
          </select>
        </label>
        <button type="submit" className="primary" disabled={running || (state.columns.length === 0 && state.measures.length === 0)}>
          {running ? 'Running...' : 'Run'}
        </button>
      </section>
    </form>
  );
}
