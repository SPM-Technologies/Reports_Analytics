import { type ColumnDef, flexRender, getCoreRowModel, useReactTable } from '@tanstack/react-table';
import { useMemo } from 'react';
import { formatColumnValue, formatValue, isNumeric } from '../format';
import type { QueryResult, SortSpec } from '../types';

interface Props {
  result: QueryResult;
  sort: SortSpec[];
  onSort: (field: string) => void;
}

/** Result grid. Sorting is done by the server (click a header), so the grid only renders one page. */
export function ResultsTable({ result, sort, onSort }: Props) {
  const columns = useMemo<ColumnDef<unknown[]>[]>(
    () => result.columns.map((c, i) => ({
      id: c.key,
      header: c.label,
      accessorFn: row => row[i],
      cell: info => formatColumnValue(info.getValue(), c),
      meta: { numeric: isNumeric(c.type, c.role) },
    })),
    [result.columns],
  );
  const table = useReactTable({ data: result.rows, columns, getCoreRowModel: getCoreRowModel() });
  const dims = result.columns.filter(c => c.role === 'dimension').length;

  return (
    <div className="table-wrap" tabIndex={0} aria-label="Report results">
      <table className="results">
        <thead>
          {table.getHeaderGroups().map(group => (
            <tr key={group.id}>
              <th className="num">#</th>
              {group.headers.map(h => {
                const s = sort.find(x => x.field === h.column.id);
                const numeric = (h.column.columnDef.meta as { numeric: boolean }).numeric;
                return (
                  <th key={h.id} className={numeric ? 'num' : undefined}
                      aria-sort={s ? (s.dir === 'asc' ? 'ascending' : 'descending') : 'none'}>
                    <button type="button" className="sort" onClick={() => onSort(h.column.id)} title="Sort">
                      {flexRender(h.column.columnDef.header, h.getContext())}
                      <span className="sort-mark">{s ? (s.dir === 'asc' ? ' ▲' : ' ▼') : ''}</span>
                    </button>
                  </th>
                );
              })}
            </tr>
          ))}
        </thead>
        <tbody>
          {table.getRowModel().rows.map((row, i) => (
            <tr key={row.id}>
              <td className="num muted">{result.offset + i + 1}</td>
              {row.getVisibleCells().map(cell => (
                <td key={cell.id} className={(cell.column.columnDef.meta as { numeric: boolean }).numeric ? 'num' : undefined}>
                  {flexRender(cell.column.columnDef.cell, cell.getContext())}
                </td>
              ))}
            </tr>
          ))}
          {result.rows.length === 0 && (
            <tr><td colSpan={result.columns.length + 1} className="empty">No rows match these filters.</td></tr>
          )}
        </tbody>
        {result.totals && (
          <tfoot>
            <tr>
              <td>Total</td>
              {result.columns.map((c, i) => (
                <td key={c.key} className={c.role === 'measure' ? 'num' : undefined}>
                  {i < dims ? '' : formatValue(result.totals![i - dims], c.type, c.role)}
                </td>
              ))}
            </tr>
          </tfoot>
        )}
      </table>
    </div>
  );
}
